Config = {}
-- Auto-detect the normal stock setup. Override only when using a nonstandard load order.
Config.Framework = 'auto' -- auto | qbox | qbcore | esx
Config.Inventory = 'auto' -- auto | ox | qb | esx_native

-- No extra clothing or assets are streamed. The rifle attaches to the freemode ped
-- in whatever *stock* clothing the player is already wearing.
Config.RequireStockClothing = false
-- Optional stock clothing whitelist. Set RequireStockClothing=true after checking
-- the actual drawable/texture on your stock GTA V build with /slingclothes.
-- These sample values are NOT required or automatically applied.
Config.StockClothing = {
    male = { { component = 8, drawable = 18, texture = 0 } },
    female = { { component = 8, drawable = 17, texture = 3 } }
}

Config.PickupDistance = 2.0
Config.DropDistance = 1.0
Config.StreamDistance = 80.0
Config.Debug = false

-- Defaults only; players may edit and save their own offsets per clothing combo.
-- These offsets attach the model closer to the chest/back of the stock freemode skeleton.
-- Different stock hoodies/vests have different thicknesses; adjust only these
-- values (metres/degrees), not the weapon identity or persistence code.
Config.AttachmentRetryMs = 1800
Config.GroundPitch = 90.0 -- turn stock vertical rifle model onto the pavement

-- Only the verified Assault Rifle from the original free sling is enabled.
-- Further stock weapons must be calibrated and tested before adding them here.
Config.WeaponName = 'WEAPON_ASSAULTRIFLE'
Config.WeaponModel = 'w_ar_assaultrifle'
Config.Attachment = {
    front = { bone = 24818, x = -0.075, y = 0.085, z = -0.055, rx = 0.0, ry = 135.0, rz = 25.0 },
    back  = { bone = 24818, x = 0.055, y = -0.105, z = 0.030, rx = 0.0, ry = 150.0, rz = -12.0 }
}

-- Editor input directions relative to the in-game stock freemode upper-spine bone.
-- This fixes the previous X=down, Z=sideways mismatch observed in-game.
-- {attachment local axis, sign} for each intended player-body direction.
Config.EditorPositionLimit = 0.5
Config.EditorMotion = {
    left={'z',-1}, right={'z',1},
    up={'x',1}, down={'x',-1},
    forward={'y',1}, backward={'y',-1}
}
