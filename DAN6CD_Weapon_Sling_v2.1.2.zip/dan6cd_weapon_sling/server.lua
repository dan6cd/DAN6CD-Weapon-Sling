local locked = {}
local databaseReady = false
local clothingProfiles = {} -- active visual offsets only; no weapon identity stored here

local function notify(src,msg) TriggerClientEvent('dan6cd_sling:message',src,msg) end
local function logDebug(msg) if Config.Debug then print('[dan6cd_weapon_sling] '..tostring(msg)) end end
local function safeAction(src,callback)
    if not databaseReady then
        return notify(src, 'Weapon Sling database not ready. Check server console for database initialization.')
    end
    if locked[src] then return notify(src,'Weapon transfer already in progress.') end
    locked[src]=true
    local ok,err=xpcall(callback,debug.traceback)
    locked[src]=nil
    if not ok then
        print(('[dan6cd_weapon_sling] Transaction error for %s: %s'):format(src,err))
        notify(src,'Weapon action failed; contact staff before trying again.')
    end
end
local function ident(src) return Bridge.identifier(src) end
local function getSlot(id,slot)
    return MySQL.single.await("SELECT * FROM dan6cd_sling_items WHERE identifier=? AND location=? AND status='active' LIMIT 1",{id,slot})
end
local function validSource(src)
    local id=ident(src)
    if not id then notify(src,'Wait until your character has loaded.');return nil end
    local ped=GetPlayerPed(src)
    if not ped or ped==0 then return nil end
    local model=GetEntityModel(ped)
    if model ~= joaat('mp_m_freemode_01') and model ~= joaat('mp_f_freemode_01') then
        notify(src,'Use a stock male or female freemode ped.')
        return nil
    end
    return id,ped
end
local function disarm(src)
    TriggerClientEvent('dan6cd_sling:disarm',src)
end
local function metadata(row)
    local ok,decoded=pcall(json.decode,row.metadata or '{}')
    return ok and type(decoded)=='table' and decoded or {}
end
local function vectorPlacement(src,ped)
    local pos, h = GetEntityCoords(ped),GetEntityHeading(ped)
    -- GTA heading: 0 = north (positive Y).
    local rad=math.rad(h)
    return pos.x-math.sin(rad)*Config.DropDistance, pos.y+math.cos(rad)*Config.DropDistance, pos.z-0.75, h
end
-- Read profiles from SQL (not only from a transient Lua cache), scoped to
-- the logged-in character + their exact outfit. Re-read at every sling toggle
-- so a weapon returning from inventory always uses the latest confirmed edit.
local function refreshProfiles(src,id,key)
    if type(key)~='string' or not id then return end
    local rows=MySQL.query.await('SELECT location,transform FROM dan6cd_sling_profiles WHERE identifier=? AND clothing_key=?',{id,key}) or {}
    local preset={key=key,identifier=id}
    for _,row in ipairs(rows) do
        if row.location=='front' or row.location=='back' then
            local ok,decoded=pcall(json.decode,row.transform)
            if ok and type(decoded)=='table' then
                local val={}
                for _,field in ipairs({'x','y','z','rx','ry','rz'}) do val[field]=tonumber(decoded[field]) end
                local valid=true
                for f,n in pairs(val) do
                    if not n or n~=n or math.abs(n)>((f=='x' or f=='y' or f=='z') and 0.5 or 360) then valid=false end
                end
                if valid and val.x and val.y and val.z and val.rx and val.ry and val.rz then
                    preset[row.location]=val
                end
            end
        end
    end
    clothingProfiles[src]=preset
end

local function sendSnapshot(target)
    if not databaseReady then return end
    local rows=MySQL.query.await("SELECT id,identifier,location,status,world_x,world_y,world_z,heading FROM dan6cd_sling_items WHERE status='active'") or {}
    local online={}
    for _,id in ipairs(GetPlayers()) do
        local sid=tonumber(id)
        local playerIdent=ident(sid)
        if playerIdent then online[playerIdent]=sid end
    end
    local entries={}
    for _,r in ipairs(rows) do
        if r.location=='ground' or online[r.identifier] then
            local sid=online[r.identifier]
            local wearer= sid and clothingProfiles[sid]
            if wearer and wearer.identifier~=r.identifier then wearer=nil end
            local offsets=wearer and wearer[r.location]
            entries[#entries+1]={id=r.id,location=r.location,serverId=sid,x=r.world_x,y=r.world_y,z=r.world_z,h=r.heading,
                transform=offsets or nil}
        end
    end
    TriggerClientEvent('dan6cd_sling:snapshot',target or -1,entries)
end
local function storeFromInventory(src,id,location,slot,ped)
    local item=Bridge.getSelected(src,tonumber(slot))
    if not item then return notify(src,'Equip one Assault Rifle. For QB, only one copy can be carried at a time.') end
    local sn=item.metadata and (item.metadata.serial or item.metadata.serie)
    if not sn or tostring(sn)=='' then
        return notify(src,'Weapon has no serial. This script refuses unsafe transfers.')
    end
    if getSlot(id,'front') and location=='front' or getSlot(id,'back') and location=='back' then
        return notify(src,'Sling position is already occupied.')
    end
    -- Persistent pending record BEFORE inventory removal. Pending rows NEVER render or auto-return.
    -- This intentionally prioritizes preventing duplicates over unsafe automatic recovery.
    local x,y,z,h=0,0,0,0
    if location=='ground' then x,y,z,h=vectorPlacement(src,ped) end
    local ok,recordId=pcall(function()
        return MySQL.insert.await([[INSERT INTO dan6cd_sling_items
            (identifier,weapon,serial,metadata,location,status,original_slot,world_x,world_y,world_z,heading)
            VALUES (?,?,?,?,?,'pending',?,?,?,?,?)]],
            {id,Config.WeaponName,tostring(sn),json.encode(item.metadata),location,tonumber(item.slot),x,y,z,h})
    end)
    if not ok or not recordId then
        return notify(src,'Could not reserve weapon; check duplicate serial or SQL errors.')
    end
    local removed=Bridge.remove(src,item)
    if not removed then
        -- A removal error can be ambiguous (especially with external inventories).
        -- Leave pending if it may have been removed; admin can resolve with SQL.
        local stillHere=Bridge.hasSerial(src,sn)
        if stillHere then
            MySQL.update.await("DELETE FROM dan6cd_sling_items WHERE id=? AND status='pending'",{recordId})
            return notify(src,'Inventory rejected transfer; rifle was not moved.')
        end
        print(('[dan6cd_weapon_sling] WARNING: pending transfer id=%s serial=%s. Manual reconciliation required.'):format(recordId,sn))
        return notify(src,'Transfer uncertain. Contact staff; DO NOT spawn another rifle.')
    end
    local updated=MySQL.update.await("UPDATE dan6cd_sling_items SET status='active' WHERE id=? AND status='pending'",{recordId})
    if updated~=1 then
        print(('[dan6cd_weapon_sling] WARNING: inventory removed but pending id %s not activated. Manual recovery needed.'):format(recordId))
        return notify(src,'Database update failed. Contact staff for recovery.')
    end
    disarm(src)
    notify(src,location=='ground' and 'Assault Rifle dropped.' or ('Assault Rifle placed on '..location..' sling.'))
    sendSnapshot()
end
local function returnRow(src,row)
    local md=metadata(row)
    if not md.serial and row.serial then md.serial=row.serial end
    if Bridge.hasSerial(src,row.serial) then
        return notify(src,'Same serial already in inventory. Staff must reconcile this record.')
    end
    local claimed=MySQL.update.await("UPDATE dan6cd_sling_items SET status='returning' WHERE id=? AND status='active'",{row.id})
    if claimed~=1 then return notify(src,'Weapon was already claimed.') end
    -- Once an item was added, NEVER blindly re-enable its physical row on SQL errors.
    local ok,added=pcall(Bridge.give,src,md,tonumber(row.original_slot))
    if not ok or not added then
        if Bridge.hasSerial(src,row.serial) then
            print(('[dan6cd_weapon_sling] CRITICAL: item added but adapter reported failure, row %d left returning.'):format(row.id))
            return notify(src,'Transfer status uncertain; staff must reconcile.')
        end
        MySQL.update.await("UPDATE dan6cd_sling_items SET status='active' WHERE id=? AND status='returning'",{row.id})
        return notify(src,'No inventory space, or framework could not return rifle.')
    end
    local deleted=MySQL.update.await("DELETE FROM dan6cd_sling_items WHERE id=? AND status='returning'",{row.id})
    if deleted~=1 then
        print(('[dan6cd_weapon_sling] CRITICAL: row %s remains returning; do not force recovery without checking inventory.'):format(row.id))
    end
    notify(src,'Assault Rifle returned to your inventory.')
    sendSnapshot()
end
local function toggle(src,location,slot)
    safeAction(src,function()
        local id,ped=validSource(src)
        if not id then return end
        local current=clothingProfiles[src]
        if current and current.key then refreshProfiles(src,id,current.key) end
        local row=getSlot(id,location)
        if row then return returnRow(src,row) end
        if type(slot)~='number' then
            -- Allow J / K to switch the ONE same weapon between slots without
            -- an inventory handoff or second row. No serial is duplicated.
            local other=location=='front' and 'back' or 'front'
            local slung=getSlot(id,other)
            if slung then
                local moved=MySQL.update.await([[UPDATE dan6cd_sling_items SET location=?
                    WHERE id=? AND identifier=? AND location=? AND status='active']],
                    {location,slung.id,id,other})
                if moved==1 then
                    notify(src,'Rifle moved from '..other..' to '..location..' sling.')
                    sendSnapshot()
                    return
                end
                return notify(src,'Could not change sling position; check server console.')
            end
            return notify(src,'Equip an Assault Rifle first.')
        end
        storeFromInventory(src,id,location,slot,ped)
    end)
end
RegisterNetEvent('dan6cd_sling:toggle',function(location,slot)
    local src=source
    if location~='front' and location~='back' then return end
    toggle(src,location,slot)
end)
RegisterNetEvent('dan6cd_sling:drop',function(slot,from)
    local src=source
    safeAction(src,function()
        local id,ped=validSource(src)
        if not id then return end
        if from=='front' or from=='back' then
            local row=getSlot(id,from)
            if not row then return notify(src,'That sling is empty.') end
            local x,y,z,h=vectorPlacement(src,ped)
            local changed=MySQL.update.await([[UPDATE dan6cd_sling_items SET location='ground',
                world_x=?,world_y=?,world_z=?,heading=? WHERE id=? AND status='active']],{x,y,z,h,row.id})
            if changed~=1 then return notify(src,'Unable to drop sling rifle.') end
            notify(src,'Slung rifle placed on the ground.')
            sendSnapshot()
        elseif type(slot)=='number' then
            storeFromInventory(src,id,'ground',slot,ped)
        else
            notify(src,'Equip a rifle, or use /dropgun front or /dropgun back.')
        end
    end)
end)
RegisterNetEvent('dan6cd_sling:pickup',function(recordId)
    local src=source
    safeAction(src,function()
        local id,ped=validSource(src)
        if not id then return end
        recordId=tonumber(recordId)
        if not recordId or recordId<1 or recordId%1~=0 then return end
        local row=MySQL.single.await("SELECT * FROM dan6cd_sling_items WHERE id=? AND location='ground' AND status='active'",{recordId})
        if not row then return end
        local pos=GetEntityCoords(ped)
        local dx,dy,dz=pos.x-row.world_x,pos.y-row.world_y,pos.z-row.world_z
        if dx*dx+dy*dy+dz*dz>(Config.PickupDistance+0.75)^2 then return notify(src,'Move closer to the rifle.') end
        returnRow(src,row)
    end)
end)
RegisterNetEvent('dan6cd_sling:request',function()
    local src=source
    safeAction(src,function()
        local id=ident(src)
        if id then sendSnapshot(-1) end
    end)
end)
RegisterCommand('slingstatus',function(src)
    if src==0 then return end
    local id=ident(src)
    if not id then return end
    safeAction(src,function()
        for _,row in ipairs(MySQL.query.await('SELECT id,location,status,serial FROM dan6cd_sling_items WHERE identifier=?',{id}) or {}) do
            notify(src,('%s: %s / %s / %s'):format(row.id,row.location,row.status,row.serial))
        end
    end)
end)
AddEventHandler('playerDropped',function() local src=source; locked[src]=nil;clothingProfiles[src]=nil; SetTimeout(1000,function() sendSnapshot() end) end)
-- Clothing-specific visual calibration. Kept separate from authoritative weapon rows.
local transformFields={'x','y','z','rx','ry','rz'}
local function validClothingKey(key)
    return type(key)=='string' and #key>=12 and #key<=180
        and key:match('^[mf][|][0-9:,|%-]+$')~=nil
end
local function clampTransform(values)
    if type(values)~='table' then return nil end
    local out={}
    for _,field in ipairs(transformFields) do
        local n=tonumber(values[field])
        if not n or n~=n or n==math.huge or n==-math.huge then return nil end
        local bound=({x=0.5,y=0.5,z=0.5,rx=360,ry=360,rz=360})[field]
        if n < -bound or n > bound then return nil end
        out[field]=math.floor(n*10000+0.5)/10000
    end
    return out
end
RegisterNetEvent('dan6cd_sling:profile:select',function(key)
    local src=source
    if not databaseReady or not validClothingKey(key) then return end
    if not ident(src) then return end
    local currentId=ident(src)
    if clothingProfiles[src] and clothingProfiles[src].key==key and clothingProfiles[src].identifier==currentId then
        return TriggerClientEvent('dan6cd_sling:profile:loaded',src,key)
    end
    -- Avoid interleaving a profile lookup and save for the same player.
    safeAction(src,function()
        local id=ident(src)
        if not id then return end
        refreshProfiles(src,id,key)
        sendSnapshot()
        TriggerClientEvent('dan6cd_sling:profile:loaded',src,key)
    end)
end)
RegisterNetEvent('dan6cd_sling:profile:save',function(location,key,values)
    local src=source
    local function ack(ok,why)
        TriggerClientEvent('dan6cd_sling:profile:saved',src,ok,why,location,key)
    end
    if location~='front' and location~='back' or not validClothingKey(key) then
        return ack(false,'Invalid clothing or sling slot')
    end
    local t=clampTransform(values)
    if not t then return ack(false,'Invalid offset values') end
    if not databaseReady then return ack(false,'Database is not ready') end
    if locked[src] then return ack(false,'Server was busy; retry Enter') end
    safeAction(src,function()
        local id=ident(src)
        if not id then return ack(false,'Character not loaded') end
        local active=clothingProfiles[src]
        if not active or active.identifier~=id or active.key~=key then
            return ack(false,'Outfit profile is not loaded; wait briefly and retry')
        end
        if not getSlot(id,location) then
            return ack(false,'No rifle on that sling')
        end
        local written=MySQL.update.await([[INSERT INTO dan6cd_sling_profiles (identifier,clothing_key,location,transform)
            VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE transform=VALUES(transform)]],{id,key,location,json.encode(t)})
        if written==nil then return ack(false,'SQL write failed') end
        -- Verify what MySQL actually persisted. Affected rows can be zero when
        -- saving exactly the same transform, so do NOT use written==1.
        local saved=MySQL.single.await('SELECT transform FROM dan6cd_sling_profiles WHERE identifier=? AND clothing_key=? AND location=?',
            {id,key,location})
        if not saved or not saved.transform then return ack(false,'SQL verification failed') end
        local ok,decoded=pcall(json.decode,saved.transform)
        local verified=ok and type(decoded)=='table'
        for _,field in ipairs(transformFields) do
            if not verified or math.abs((tonumber(decoded[field]) or 9999)-t[field])>0.00011 then
                verified=false
                break
            end
        end
        if not verified then return ack(false,'SQL verification mismatch') end
        active[location]=t
        sendSnapshot()
        ack(true)
    end)
end)

-- Self-initialize only the two independent DAN6CD tables; never touch inventory or physical_core tables.
-- CREATE TABLE IF NOT EXISTS is idempotent and preserves pre-existing rows.
local schema = {
    [=[-- New independent storage. NEVER import old weapon_sling or physical_core tables automatically.
CREATE TABLE IF NOT EXISTS dan6cd_sling_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identifier VARCHAR(120) NOT NULL,
    weapon VARCHAR(80) NOT NULL,
    serial VARCHAR(120) NOT NULL,
    metadata LONGTEXT NOT NULL,
    location VARCHAR(10) NOT NULL,
    status VARCHAR(15) NOT NULL DEFAULT 'pending',
    original_slot INT DEFAULT NULL,
    world_x DOUBLE DEFAULT NULL,
    world_y DOUBLE DEFAULT NULL,
    world_z DOUBLE DEFAULT NULL,
    heading DOUBLE DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_dan6cd_serial (serial),
    INDEX idx_owner_location_status (identifier,location,status),
    INDEX idx_ground_status (location,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]=],
    [=[CREATE TABLE IF NOT EXISTS dan6cd_sling_native (
    identifier VARCHAR(120) NOT NULL,
    weapon VARCHAR(80) NOT NULL,
    metadata LONGTEXT NOT NULL,
    PRIMARY KEY(identifier,weapon)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]=],
    [=[CREATE TABLE IF NOT EXISTS dan6cd_sling_profiles (
    identifier VARCHAR(120) NOT NULL,
    clothing_key VARCHAR(180) NOT NULL,
    location VARCHAR(10) NOT NULL,
    transform LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY(identifier,clothing_key,location)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]=]
}
AddEventHandler('onResourceStart',function(resource)
    if resource~=GetCurrentResourceName() then return end
    MySQL.ready(function()
        CreateThread(function()
            local ok, err = xpcall(function()
                for _, statement in ipairs(schema) do
                    MySQL.query.await(statement)
                end
            end, debug.traceback)
            if not ok then
                print('[dan6cd_weapon_sling] DATABASE SETUP FAILED: '..tostring(err))
                print('[dan6cd_weapon_sling] Check oxmysql connection and run database.sql manually in the connected database.')
                return
            end
            databaseReady = true
            print('[dan6cd_weapon_sling] Database ready: dan6cd_sling_items + dan6cd_sling_native + dan6cd_sling_profiles')
            sendSnapshot()
        end)
    end)
end)
