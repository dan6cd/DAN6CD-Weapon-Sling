DAN6CD v2.0.1 database fix
Root cause: missing dan6cd_sling_items table.
This version creates dan6cd_sling_items and dan6cd_sling_native on resource start (requires CREATE permission).
If creation fails, import database.sql into the SAME database configured for oxmysql.
Look for [dan6cd_weapon_sling] Database ready: ... in server console.
This is still a test build. Back up existing data; do not run alongside other sling/physical owner scripts.
