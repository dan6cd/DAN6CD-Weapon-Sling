# DAN6CD Weapon Sling v2.0.2 — why the rifle floated

Previous v2.0.1 client used `CreateObjectNoOffset(...,0,0,0)` and `AttachEntityToEntity(..., isPed=false, rotationOrder=2, ...)`, never validating that the attachment took effect. In-world objects were frozen upright when ground collision was unavailable.

The fixed client creates the object adjacent to its ped, uses the correct ped bone index and rotation flags, checks the attachment after every scan, and deletes any rifle visual that cannot attach instead of leaving an unrelated prop hovering in the world. It also moves front/back offsets toward the torso, aligns ground props horizontally, and retries collision placement. The server retains its original SQL and transfer checks; visuals have no inventory authority.

## Diagnostic test
1. In a clean test server with the v2.0.2 ZIP installed, ensure only `dan6cd_weapon_sling` controls this rifle.
2. Equip a serialized Assault Rifle, press J. Type `/slingattach` and confirm it says `attached=true`.
3. Walk, turn, sprint, jump and change camera. The visual rifle must follow your body. Repeat with `/backsling`.
4. Use `/dropgun front` or `/dropgun back`; the ground rifle must remain grounded. Press E to pick up.
5. Confirm with another player; ensure the weapon serial is retained by ox_inventory and no duplicate appears.
6. If attached=true but clipping, adjust **only** `Config.Attachment.front` or `back` X/Y/Z and RX/RY/RZ to match your chosen stock outfit; then restart the resource. A hoodie is thicker than a T-shirt.
7. If attached=false, copy F8 errors and confirm the player uses a stock male/female freemode ped.

This is a test release, not verified on a live client in this environment.
