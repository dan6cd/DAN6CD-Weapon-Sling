# v2.1.1 test report

- `texluac -p`: client.lua, server.lua, bridge/server.lua and config.lua compile.
- Server mock: oxmysql table ready, profile select acknowledged, sling to front,
  save transform, SQL row verification, return rifle to inventory, re-sling.
  Re-sling snapshot included exactly the saved transform.
- Editor controls updated to body-relative bone axis mapping observed in user
  screenshots. Actual in-game mapping and key behavior **not live-tested**.
- DB save acknowledgement is returned only after an independent SELECT reads
  the newly saved data. Simulated DB was in-memory, not production MySQL.
- Supported stock adapters were not reverified end-to-end on real servers.
- Original v2.1.0 database.sql retained: no migration and no reset.
- This is a **TEST BUILD**, not a release certified for production use.
