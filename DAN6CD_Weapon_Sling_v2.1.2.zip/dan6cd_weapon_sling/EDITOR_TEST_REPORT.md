# DAN6CD Weapon Sling 2.1.0 Outfit Editor — Test Report

**Status:** Development/test release, NOT live FiveM certified.

## Verified locally with LuaTeX Lua interpreter
- Lua syntax passed for `client.lua`, `server.lua`, `bridge/server.lua`, `config.lua`.
- Simulated server-side database startup creates/recognizes all three tables.
- Simulated clothing-profile save for an occupied sling slot persists x/y/z and rotations.
- Simulated snapshot includes the saved transformation, making it available to other clients.
- Switching a slung weapon between front/back updates the same persisted weapon row.
- Saving a profile for an unoccupied slot is refused.
- Out-of-bounds positions/rotations are rejected.
- Choosing a different, unsaved clothing combination uses default offsets.
- Simulated client validates J (front) / K (back) bindings, opens editor against an existing attached cosmetic prop, moves it in response to a directional control, and sends a save request.

## Still requires live tests on FiveM
- Verify controls, editor HUD, bone-axis signs and offsets on both freemode models.
- Verify profiles for multiple saved outfits through relog and server restart.
- Verify remote players see changes when owner saves or changes clothes.
- Test interrupted saving, database failures and full inventories.
- Validate item ownership and metadata transfers on stock Qbox/ox_inventory, QBCore/qb-inventory and ESX.
- Verify no collision, model or animation issues for other supported outfits.

Do not confuse simulated/local tests with a verified public release.
