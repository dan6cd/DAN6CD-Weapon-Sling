# DAN6CD Weapon Sling — Live Editor v2.1.1 (TEST)

This update fixes saved outfit offsets resetting when a rifle is returned from
inventory and adds the requested controls. It does not replace GTA V's built-in
clothing, change weapon identity, or create any new weapon item.

## Start

1. Place the serialized Assault Rifle on FRONT with **J**, or BACK with **K**.
2. Wait briefly after changing clothes for the server outfit preset to load.
3. Run `/slingedit front` or `/slingedit back`.
4. Adjust, press **ENTER**, and **wait for the message `Saved to MySQL`**.
   Do not treat `Saving...` as confirmation. If a save fails the editor remains open.
5. Return rifle to inventory with the active sling key, then re-sling and confirm
   your **same saved position** is restored. Repeat for another outfit as needed.

## Controls

| Key | Action |
|---|---|
| Arrow LEFT | Move weapon LEFT relative to body |
| Arrow RIGHT | Move weapon RIGHT relative to body |
| Arrow UP | Move weapon UP |
| Arrow DOWN | Move weapon DOWN |
| PAGE UP | Move weapon FORWARD / away from back toward chest |
| PAGE DOWN | Move weapon BACKWARD |
| Tap LEFT SHIFT | Cycle rotation axis **Z → Y → X → Z** |
| Q / E | Rotate selected axis negative / positive |
| Hold LEFT SHIFT (over ~0.22s) while adjusting | Faster movement and rotation |
| ENTER | Request DB save; wait for confirmation |
| BACKSPACE | Cancel and restore starting position |
| DELETE | Preview default offset (Enter to save) |

Coordinates (`x/y/z`) in the panel are **native GTA attachment bone coordinates**.
On the player's stock ped upper-spine bone, X behaved as vertical and Z as
horizontal in the supplied screenshots. Therefore the arrow keys operate on
body movement directions, rather than the literal X/Y/Z field letters.

If a different ped/skeleton build reverses a direction, change only the
`Config.EditorMotion` signs in `config.lua`, not the weapon model or saved
ownership data. The corrected mapping is configurable independently of the
weapon identity and SQL ledger.

## Save / persistence troubleshooting

- Confirm `dan6cd_sling_profiles` exists in the connected MySQL database.
- If editor says *profile still loading*, wait ~2 seconds. It retries when the
  server was busy during the first profile selection request.
- Only success after SQL upsert + SELECT verification closes the editor.
- Profile is keyed by **character ID + male/female freemode outfit components
  (3,7,8,9,11) + FRONT/BACK slot**.
- Reslinging actively re-reads saved SQL for the current loaded outfit.
- Use the same clothing combination to confirm restoration. Changed top,
  undershirt, vest or accessory selects a different preset.
- No table wipe or SQL migration is required from v2.1.0.
- If the server action fails, check F8/txAdmin; never spawn another weapon to
  work around a transfer failure.

## Scope

Stock Qbox + ox_inventory, QBCore + qb-inventory/ox, ESX legacy adapters as
in earlier releases. Live FiveM end-to-end verification still required.
