# Test report — v2.0.0-clean-test

- Manifest/config/client/server/bridge parsed successfully with Lua `loadfile` (texlua runtime).
- Server adapter round-trip smoke test passed for Qbox+ox_inventory, QBCore+qb-inventory, and ESX+native loadout, using fake player inventories, simulated serials and a mock SQL sidecar.
- Package audit: no custom YDD, YTD, assetpacks file, .fxap or escrowed Lua included. GTA V's built-in rifle prop is used.
- **Not yet verified**: true FiveM networking, ped bone offsets, animation and controls, MySQL transactions against a live server, concurrent players, restart recovery, actual stock clothing indices, ESX ammo sync, and inventory API behavior across all versions.
- State transitions intentionally leave ambiguous transfers in `pending` / `returning` for staff reconciliation rather than spawning duplicates.
- This rebuild does **not migrate** your prior protected or unprotected sling database records. Do not deploy against live character weapons without backups and a clean test server.

## v2.0.1 database initialization patch

- All Lua files parsed via `texlua loadfile`, including the updated server.
- Mocked `onResourceStart` with a simulated `MySQL.ready` callback confirmed that both table-creation statements run **before** the first inventory snapshot SELECT.
- `CREATE TABLE IF NOT EXISTS` keeps existing tables/records. No migration or inventory action occurs during initialization.
- **Not live verified:** MySQL privileges / connection-string, actual FiveM/oxmysql event timing, or weapon-transfer behavior on a real server.


## v2.0.2 attachment and ground-visual tests (not live FiveM)

- `texluac -p` passed for all Lua files in the resource.
- Native-mocked client lifecycle tests passed: a slung rifle is spawned near the ped, attached through a resolved ped bone index with `isPed=true`, and the front Y offset is moved close to the torso.
- A simulated temporary detachment reattached the existing local prop without creating a new one.
- A simulated failed attachment deleted the dangling local prop, and a failed new back attach also deleted the object instead of showing a floating rifle.
- A location transition to `ground` removed the slung visual and placed a ground visual through the horizontal-rotation/ground-placement path.
- Database schema and server/bridge transfer Lua code are byte-for-byte unchanged from v2.0.1; these changes affect cosmetics only.
- NOT TESTED: physical freemode bone transforms, precise hoodie/vest clipping, streamed ground collision, multiplayer replication, and weapon handling in a live Qbox/QBCore/ESX server.
