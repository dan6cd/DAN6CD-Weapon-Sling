> **v2.1.2 TEST:** Fixed an editor-session race in `client.lua` that could crash `/slingedit back` with `attempt to index a nil value (upvalue editor)`. See `V2_1_2_EDITOR_HOTFIX.md`. This remains a live-testing build.

# DAN6CD Weapon Sling — STOCK Framework & Clothing Edition

**Version: 2.1.1-editor-save-controls-test — free, source-readable testing release.**

This is a **clean standalone rebuild** based on the earlier editable Weapon Sling design. It is not a decrypted copy of the Cfx Portal asset and **does not replace your original weapon_sling or physical_equipment** project.

## What's included

- A single GTA V **Assault Rifle (`WEAPON_ASSAULTRIFLE`)** carried on front or back.
- Uses the stock in-game **`w_ar_assaultrifle`** rifle prop, built-in male/female freemode characters, and whatever **stock clothing** the player wears. **No streamed YDD/YTD clothing**, custom textures, shop items, menus, or asset packs.
- Server-validated inventory-to-front/back/world transfers, serial verification, MySQL persistence of slung or dropped weapons, ground pickup with **E**, and lightweight client-only props synced to nearby players.
- No ox_lib requirement; **oxmysql** is required for persistence.
- Vanilla player clothing is **not modified by the script**. There is no visual strap/clothing asset in this edition; the weapon is attached to the ped as a prop.

## Stock framework support

| Framework | Inventory | Notes |
|---|---|---|
| Qbox `qbx_core` | `ox_inventory` | Primary supported adapter |
| QBCore `qb-core` | `qb-inventory` | Refuses ambiguous multiple Assault Rifles |
| QBCore `qb-core` | `ox_inventory` | Requires compatible QB/ox integration |
| ESX Legacy `es_extended` | `ox_inventory` | Preferred ESX integration |
| ESX Legacy `es_extended` | Built-in ESX loadout | Best effort; one rifle per weapon type, serial stored separately |

Only one inventory should be active. Other frameworks/inventories are not implemented. **Live FiveM end-to-end testing is still required** for each combination.

## Installation

1. Back up your database, and **stop** the old `weapon_sling`, `weapon_sling_free`, and any equipment script controlling the same weapon. Never run this beside `physical_core` weapon ownership or `physical_equipment` for the same rifle.
2. Extract `dan6cd_weapon_sling/` to `resources/[standalone]/`.
3. The resource now **automatically creates its own three tables on startup** using `CREATE TABLE IF NOT EXISTS`. You can also import **`database.sql`** manually into the oxmysql-connected database if your server's DB user lacks `CREATE` permission. No migration from the old build.
4. Set the **framework and inventory to start first**, then `oxmysql`, then the resource (oxmysql itself may start before the framework):

```cfg
ensure oxmysql
ensure qbx_core        # OR qb-core OR es_extended
ensure ox_inventory   # OR qb-inventory; ESX native needs no inventory resource
ensure dan6cd_weapon_sling
```

Remove the lines for resources you do not use. Start `ox_inventory` in your normal framework-approved order. Do not run both ox_inventory and qb-inventory.

5. Leave `Config.Framework` and `Config.Inventory` at `auto` unless your server has special resource names. Confirm the server console prints the detected pair.
6. Equip a serialized stock Assault Rifle; press `J` or use `/sling` to put it on your front; `K` or `/backsling` for your back. Use the same command to return the rifle to inventory. Use `/dropgun` while holding a rifle, or `/dropgun front` / `/dropgun back` to place a slung rifle on the ground. Press **E** near a dropped rifle to pick it up.
7. Test weapon ammo, serial, components, inventory-slot return, relog/restart, full inventory refusal, nearby players, ground pickup contention, and both ped models **before publishing on a live server**.

## Vanilla clothing options

`Config.RequireStockClothing=false` by default. This supports standard male and female freemode ped models with their normal GTA clothing; it never spawns an outfit or adds mod clothing.

If you want to require a specific **stock outfit that looks like it has a strap**, choose that outfit on your own stock server, run `/slingclothes` and read its **component:drawable/texture** values. Enter those numbers into `Config.StockClothing` and set `RequireStockClothing=true`. The sample presets included in the config were inherited from the previous configuration and are **NOT guaranteed to be part of every stock server/DLC build**. Changing clothing validation is client-side/cosmetic; server-side inventory transfers remain authenticated.

## Commands

- `J` or `/sling` — store/return the equipped Assault Rifle on the front.
- `K` or `/backsling` — store/return from back; when rifle is already in the other slot, switch it without duplicating or passing through inventory.
- `/dropgun` — ground-drop equipped Assault Rifle.
- `/dropgun front` / `/dropgun back` — ground-drop a slung rifle.
- `E` near ground rifle — pick up.
- `/slingclothes` — inspect your current stock clothing indices.
- `/slingstatus` — view your persistent storage entries (including pending / returning rows).

## Data integrity and troubleshooting

This resource is **one-authority-at-a-time**: inventory owns the rifle until the server removes its serial; the MySQL row owns it while slung/dropped; restoring the weapon removes the row. Client props are visual-only. It deliberately refuses to create a second copy of a serial that is already in inventory.

**Important non-atomic boundary:** Inventory APIs and SQL are two different systems. Crashes between them can leave a row in `pending` or `returning`. The script **never auto-retries ambiguous transfers**, which would risk duplication. An administrator must inspect the inventory item and `dan6cd_sling_items` row by serial before repairing it. See `TROUBLESHOOTING.md`.

**No automatic migration:** Do not import the old `weapon_sling_items`, `weapon_sling_transforms` or `physical_core` data. Return weapons with the prior script and remove it before using this edition. Any migration needs a verified one-to-one serial audit.

**No custom sling animation or streamed clothing:** The old complex editor, stream assets, debugging hooks and clothing YDD/YTD models are excluded. A NEW lightweight in-game placement editor is now included. Standard weapon draw/equip follows the stock inventory system. This release focuses on essential, stable functionality.

**Not live certified:** The code has been statically checked, but no full server with Qbox, QBCore or ESX is available in this environment. Publish as a test release until each supported path is verified.

## v2.0.1 database-fix update

- Automatically creates `dan6cd_sling_items` and `dan6cd_sling_native` when oxmysql is ready, before accepting weapon actions.
- Failed setup logs a clear `DATABASE SETUP FAILED` error; weapon actions are refused until initialization succeeds.
- Does **not** reset, delete or migrate any previously saved weapons.
- For existing installs, stop this resource, back up your database, copy in the new version and restart the resource.
- Manual alternative: use `DAN6CD_Weapon_Sling_Database_Fix.sql` in the database specified by `mysql_connection_string`.
- This is a **test fix**, not a claim of live end-to-end validation.


## v2.0.2 stock-body attachment + drop visual fix (test build)

- Fixed client-side visual prop creation at world origin: the rifle now spawns near the ped/ground record.
- Uses `GetPedBoneIndex(ped, 24818)` and an `isPed=true` AttachEntityToEntity call, reusing the original attachment flag/rotation order combination. Front Y distance reduced from +0.265m to +0.085m. Back Y changed from -0.22m to -0.105m.
- Checks `IsEntityAttachedToEntity` and automatically reattaches after loss; if attachment fails, the visual prop is deleted instead of being left floating. The check also handles nearby player ped recreation and switching between front/back.
- Ground rifle is rotated onto its side, waits for collision/ground placement, and hides until positioned. Adjust `Config.GroundPitch` only if your specific rifle model lies on the wrong side.
- Client diagnostic `/slingattach` prints attachment status (`attached=true/false`) and distance to the ped in FiveM F8 and as a notification. `/slingstatus` still reports server records.
- Only the visual client and config were changed. No SQL migration is needed and inventory/database ownership logic is unchanged.
- **Offsets are starting values, not a live-certified fit for every hoodie or freemode clothing drawable.** Fine-tune `Config.Attachment.front/back` in `config.lua` if clipping or angle adjustments are needed.
- Stop the resource, back up your original, replace `dan6cd_weapon_sling` (do not run two copies), and `ensure dan6cd_weapon_sling`. Test J, /backsling, moving/running, other nearby players, /dropgun, pickup, relog and restart.


## v2.1.0 — live sling placement editor & outfit-specific saved positions

This edition keeps the same original stock rifle model and clothing. It adds only a
**cosmetic** placement editor to the working v2.0.2 attachment logic. It does not
change weapon serials, inventory ownership, ammunition, ground transfers or gameplay weapons.

**Keys:** `J` = front sling, `K` = back sling. From an occupied front/back slot,
pressing the other key moves the *same database weapon row* between the two locations.
Tap the matching key again to return the rifle to inventory.
The keybinds are configurable under GTA/FiveM Settings > Key Bindings > FiveM.

### Opening the editor

1. Put the rifle on the front using `J` or back using `K`.
2. Run `/slingedit front` or `/slingedit back`. You can run `/slingedit` to edit
   whichever position currently holds a rifle.
3. Stand in third-person, turn the camera, and adjust until the rifle sits on the
   hoodie/vest/pocket or other current **stock** outfit as desired.
4. Press `ENTER` to save this character's profile for the current combination of
   torso (3), chains (7), undershirt (8), vest (9) and jacket (11) components.
5. Wear the same clothing later and the saved transform is selected again;
   other clients see your profile through the server snapshot.

### Editor controls

| Key | Adjustment |
|---|---|
| Arrow Left / Right | Shift rifle sideways (attachment X) |
| Arrow Up / Down | Forward / backward from chest (attachment Y) |
| Page Up / Page Down | Higher / lower on body (attachment Z) |
| TAB | Cycle X, Y, Z **rotation axis** |
| Q / E | Rotate on selected axis (negative / positive) |
| Hold Left Shift | Faster movement / rotation |
| Delete | Preview default front/back position (save to keep) |
| Enter | Save position to MySQL for character + outfit + sling side |
| Backspace | Cancel, restore pre-edit position |

**Important:** Start the editor ONLY if a real slung rifle is already attached.
It will not spawn a new rifle or bypass the server's inventory validation. A
failed or cancelled edit does not touch the database weapon row. You can save
front and back offsets independently. Custom holster positions use the same
**stock ped bone**; this resource does not add clothing slots or straps.

### Profile storage and syncing

The new third table `dan6cd_sling_profiles` is automatically created on resource
startup (or import `database.sql` manually). It contains **cosmetic** x/y/z and
rotation data only and is separate from the weapon item ledger. Profile saves are
validated for active sling ownership, selected outfit key and numeric bounds.
A player's calibration is replicated to other clients viewing their slung rifle.

Test on live Qbox/QBCore/ESX servers, with two players and both ped models before
publishing as stable. Old profile records are preserved; existing slung rifles
should continue to persist. If you have a modified older client.lua/server.lua,
back it up before replacing the complete folder.


## v2.1.1 — Editor controls & verified profile persistence (TEST)

- **Arrow LEFT / RIGHT** moves left/right on the body (bone Z). **Arrow UP / DOWN**
  moves vertically (bone X). **PAGE UP / DOWN** moves forward/backward (bone Y).
  `Config.EditorMotion` lets server owners reverse these signs if their stock
  ped build's bone orientation differs.
- **Tap LEFT SHIFT** switches rotation axis Z → Y → X → Z. **Hold LEFT SHIFT**
  > 220ms while adjusting for larger steps. **Q/E** rotates selected axis.
- Saving with **ENTER** keeps editor open until a confirmed SQL upsert is
  independently read back. `Saved to MySQL` means the row was verified;
  `Saving...` does not. On failure the editor stays open for retry.
- Profile requests retry after a rejected/busy selection and only become
  active after the server confirms the correct character/outfit was loaded.
- On each sling toggle, the server re-reads the current character/outfit
  profile from MySQL before creating the next cosmetic prop snapshot, so
  returning the rifle to inventory and sling restores the saved position.
- Reuses the existing `dan6cd_sling_profiles` table. **NO SQL changes or
  schema reset**. Previous saved transforms are kept.
- Existing weapon identity, inventory, serial and location transitions remain
  separate and authoritative on the server.

**Verification limits:** Lua files passed compiler syntax checks, and a mocked
server/database test covered a successful save, returning the weapon to
inventory and re-slinging with the preserved transform. The bone-direction
mapping is based on the user-provided in-game observations, not a live server
run. Test visually on Qbox first, then QBCore/ESX and both freemode peds.
