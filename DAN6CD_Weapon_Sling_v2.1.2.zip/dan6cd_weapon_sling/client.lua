-- DAN6CD free edition: vanilla GTA V weapon prop + existing stock freemode clothing.
local visible={} -- per-client cosmetic props only; never inventory items.
local retryAfter={} -- cooldown for failed attachment; avoids prop respawn loops.
local editor=nil -- client-only live preview; not a weapon/inventory item
local outfitKey=nil -- confirmed by server, never set merely when requesting
local requestedOutfitKey=nil
local lastOutfitRequest=0
local state={}
local pendingEditorSave=nil -- wait for confirmed DB acknowledgement before closing
local hash=joaat(Config.WeaponName)
local model=joaat(Config.WeaponModel)
local function message(text)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('~b~DAN6CD Weapon Sling~s~: '..tostring(text))
    EndTextCommandThefeedPostTicker(false,false)
end
RegisterNetEvent('dan6cd_sling:message',message)
local function validPed(ped)
    if ped==0 or not DoesEntityExist(ped) then return false end
    local m=GetEntityModel(ped)
    return m==joaat('mp_m_freemode_01') or m==joaat('mp_f_freemode_01')
end
local function clothingOK(ped)
    if not validPed(ped) then return false end
    if not Config.RequireStockClothing then return true end
    local gender=GetEntityModel(ped)==joaat('mp_m_freemode_01') and 'male' or 'female'
    for _,rule in ipairs(Config.StockClothing[gender] or {}) do
        if GetPedDrawableVariation(ped,rule.component)==rule.drawable
            and GetPedTextureVariation(ped,rule.component)==rule.texture then return true end
    end
    return false
end
local function selectedSlot()
    local ped=PlayerPedId()
    if GetSelectedPedWeapon(ped)~=hash then return nil end
    if GetResourceState('ox_inventory')=='started' then
        local ok,w=pcall(function() return exports.ox_inventory:getCurrentWeapon() end)
        return ok and w and tostring(w.name):upper()==Config.WeaponName and tonumber(w.slot) or nil
    end
    if GetResourceState('qb-inventory')=='started' then
        local ok,playerData=pcall(function() return exports['qb-core']:GetCoreObject().Functions.GetPlayerData() end)
        if not ok or not playerData then return nil end
        local count,slot=0,nil
        for _,w in pairs(playerData.items or {}) do
            if tostring(w.name):upper()==Config.WeaponName then
                count=count+1;slot=tonumber(w.slot)
            end
        end
        return count==1 and slot or nil
    end
    if GetResourceState('es_extended')=='started' then return 1 end
    return nil
end
local function toggle(location)
    if editor then return message('Save or cancel the sling editor first.') end
    if not clothingOK(PlayerPedId()) then
        return message('Use a stock freemode ped and an allowed stock clothing preset.')
    end
    TriggerServerEvent('dan6cd_sling:toggle',location,selectedSlot())
end
RegisterCommand('sling',function() toggle('front') end,false)
RegisterKeyMapping('sling','DAN6CD: front weapon sling','keyboard','J')
RegisterCommand('backsling',function() toggle('back') end,false)
RegisterKeyMapping('backsling','DAN6CD: back weapon sling','keyboard','K')
RegisterCommand('dropgun',function(_,args)
    if editor then return message('Close the sling editor before dropping the weapon.') end
    local from=args[1] and args[1]:lower() or nil
    if from~='front' and from~='back' then from=nil end
    TriggerServerEvent('dan6cd_sling:drop',selectedSlot(),from)
end,false)
RegisterCommand('slingclothes',function()
    local ped=PlayerPedId()
    if not validPed(ped) then return message('Stock freemode character required.') end
    local s={}
    for _,component in ipairs({3,7,8,9,11}) do
        s[#s+1]=('%d:%d/%d'):format(component,GetPedDrawableVariation(ped,component),GetPedTextureVariation(ped,component))
    end
    message('Stock clothing component:drawable/texture = '..table.concat(s,'  '))
end,false)
RegisterNetEvent('dan6cd_sling:disarm',function()
    if GetResourceState('ox_inventory')=='started' then TriggerEvent('ox_inventory:disarm',true) end
    local ped=PlayerPedId()
    SetCurrentPedWeapon(ped,joaat('WEAPON_UNARMED'),true)
    RemoveWeaponFromPed(ped,hash)
end)
RegisterNetEvent('dan6cd_sling:snapshot',function(snapshot)
    if type(snapshot)~='table' then return end
    state=snapshot
end)
local function clear(key)
    local value=visible[key]
    if value and value.obj and DoesEntityExist(value.obj) then DeleteEntity(value.obj) end
    visible[key]=nil
end
-- The client creates visuals only; the server still owns every inventory/SQL transfer.
-- IMPORTANT: a successful CreateObject is not evidence that it is attached.
local function debugAttach(text)
    if Config.Debug then print('[dan6cd_weapon_sling] '..tostring(text)) end
end

local function loadModel()
    if HasModelLoaded(model) then return true end
    RequestModel(model)
    return false
end

-- Spawn near the target, not at (0,0,0). The old code could leave a local
-- object at a world position when GTA did not complete the ped attachment.
local function createProp(coords)
    if not HasModelLoaded(model) then return nil end
    local obj=CreateObjectNoOffset(model,coords.x,coords.y,coords.z,false,false,false)
    if not obj or obj==0 or not DoesEntityExist(obj) then return nil end
    SetEntityAsMissionEntity(obj,true,true)
    SetEntityInvincible(obj,true)
    SetEntityCollision(obj,false,false)
    SetEntityVisible(obj,true,false)
    SetEntityAlpha(obj,255,false)
    return obj
end

local function attachToSpine(obj,ped,location,offsets)
    local t=offsets or Config.Attachment[location]
    if not t or not DoesEntityExist(obj) or not validPed(ped) then return false end
    local bone=GetPedBoneIndex(ped,tonumber(t.bone) or 24818)
    if not bone or bone<0 then
        debugAttach(('Invalid ped bone for %s: %s'):format(location,tostring(bone)))
        return false
    end
    -- Use the attachment flags and rotation order from the original sling.
    -- The old simplified edition set isPed=false; that restricts pitch/roll.
    -- This is a cosmetic prop attached to a PED BONE, not a new weapon item.
    if IsEntityAttached(obj) then DetachEntity(obj,true,true) end
    FreezeEntityPosition(obj,false)
    SetEntityCollision(obj,false,false)
    SetEntityRotation(obj,0.0,0.0,0.0,1,true)
    AttachEntityToEntity(obj,ped,bone,
        t.x,t.y,t.z,t.rx,t.ry,t.rz,
        true,true,false,true,1,true)
    SetEntityVisible(obj,true,false)
    SetEntityAlpha(obj,255,false)
    local attached=IsEntityAttachedToEntity(obj,ped)
    if not attached then
        debugAttach(('Failed to attach %s (ped=%s, bone=%s, object=%s)')
            :format(location,tostring(ped),tostring(bone),tostring(obj)))
    end
    return attached
end

local function worldPosition(r)
    return vector3(tonumber(r.x) or 0,tonumber(r.y) or 0,tonumber(r.z) or 0)
end

local function placeOnGround(obj,r)
    local target=worldPosition(r)
    RequestCollisionAtCoord(target.x,target.y,target.z)
    -- Leave it hidden until ground placement succeeds. Avoid freezing a rifle
    -- standing vertically or hovering in the air when collision isn't streamed.
    SetEntityVisible(obj,false,false)
    FreezeEntityPosition(obj,false)
    SetEntityCollision(obj,true,true)
    local groundFound,groundZ=GetGroundZFor_3dCoord(target.x,target.y,target.z+3.0,false)
    local z=groundFound and groundZ or target.z
    SetEntityCoordsNoOffset(obj,target.x,target.y,z+0.55,false,false,false)
    SetEntityRotation(obj,Config.GroundPitch or 90.0,0.0,tonumber(r.h) or 0.0,2,true)
    local placed=PlaceObjectOnGroundProperly(obj)
    -- When collision is still loading, retry on the next scan; never display
    -- an unplaced rifle. This also avoids breaking the stored server coords.
    if not placed and not groundFound then
        SetEntityCollision(obj,false,false)
        return false
    end
    if not placed then
        -- Fallback for a collisionless stock prop: center just above pavement.
        SetEntityCoordsNoOffset(obj,target.x,target.y,groundZ+0.10,false,false,false)
    end
    FreezeEntityPosition(obj,true)
    SetEntityCollision(obj,false,false)
    SetEntityVisible(obj,true,false)
    SetEntityAlpha(obj,255,false)
    return true
end

local function drawHelp(text)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0,false,false,-1)
end

-- Track one local visual for each unique server-owned weapon record.
-- Losing attachment never creates an additional authoritative inventory item.
local function scan()
    local pos=GetEntityCoords(PlayerPedId())
    local wanted={}
    local nearest=nil
    local nearestD=Config.PickupDistance
    for _,r in ipairs(state) do
        local key=tostring(r.id)
        if r.location=='ground' then
            local target=worldPosition(r)
            local d=#(pos-target)
            if d<=Config.StreamDistance then
                wanted[key]={row=r,ground=true}
                if d<nearestD then nearestD=d; nearest=r end
            end
        elseif (r.location=='front' or r.location=='back') and r.serverId then
            local player=GetPlayerFromServerId(tonumber(r.serverId))
            if player~=-1 then
                local ped=GetPlayerPed(player)
                if validPed(ped) and #(pos-GetEntityCoords(ped))<=Config.StreamDistance then
                    wanted[key]={row=r,ped=ped,ground=false}
                end
            end
        end
    end
    for key in pairs(visible) do if not wanted[key] then clear(key);retryAfter[key]=nil end end
    for key,w in pairs(wanted) do
        local old=visible[key]
        local changed=old and (old.ped~=w.ped or old.ground~=w.ground
            or old.location~=w.row.location)
        if changed then clear(key);old=nil end
        if old and not DoesEntityExist(old.obj) then clear(key);old=nil end

        if old and not w.ground and not IsEntityAttachedToEntity(old.obj,w.ped) then
            -- Hide immediately: never show an unattached rifle floating while retrying.
            SetEntityVisible(old.obj,false,false)
            -- The key fix: never leave an unattached rifle frozen at world coords.
            local now=GetGameTimer()
            if now-(old.lastAttempt or 0)>=Config.AttachmentRetryMs then
                old.lastAttempt=now
                if not attachToSpine(old.obj,w.ped,w.row.location, editor and editor.recordId==key and editor.values or w.row.transform) then
                    -- Clean up and retry with a fresh local object later.
                    clear(key);old=nil
                    retryAfter[key]=now+Config.AttachmentRetryMs
                end
            end
        elseif old and w.ground and not old.placed then
            old.placed=placeOnGround(old.obj,w.row)
        elseif old and not w.ground and not (editor and editor.recordId==key) then
            local t=w.row.transform or Config.Attachment[w.row.location]
            -- A cosmetic profile update must take effect on all watching clients.
            local changedOffset=not old.applied
            if not changedOffset then
                for _,field in ipairs({'x','y','z','rx','ry','rz'}) do
                    if math.abs((old.applied[field] or 0)-(t[field] or 0))>0.00001 then
                        changedOffset=true; break
                    end
                end
            end
            if changedOffset then
                if attachToSpine(old.obj,w.ped,w.row.location,t) then
                    old.applied={x=t.x,y=t.y,z=t.z,rx=t.rx,ry=t.ry,rz=t.rz}
                else clear(key); old=nil end
            end
        end

        if not old and GetGameTimer()>=(retryAfter[key] or 0) and loadModel() then
            local coords=w.ground and worldPosition(w.row) or GetEntityCoords(w.ped)
            local obj=createProp(coords)
            if obj then
                if w.ground then
                    local placed=placeOnGround(obj,w.row)
                    visible[key]={obj=obj,ped=nil,ground=true,location='ground',placed=placed}
                elseif attachToSpine(obj,w.ped,w.row.location, editor and editor.recordId==key and editor.values or w.row.transform) then
                    local t=w.row.transform or Config.Attachment[w.row.location]
                    visible[key]={obj=obj,ped=w.ped,ground=false,
                        location=w.row.location,lastAttempt=GetGameTimer(),placed=true,
                        applied={x=t.x,y=t.y,z=t.z,rx=t.rx,ry=t.ry,rz=t.rz}}
                else
                    -- Never show a floating unbound cosmetic rifle.
                    DeleteEntity(obj)
                    retryAfter[key]=GetGameTimer()+Config.AttachmentRetryMs
                end
            end
        end
    end
    return nearest
end

-- Live transform editor: never duplicates or transfers an authoritative weapon.
-- Offset profiles are stored server-side by character+outfit+front/back and
-- replicated in the sling snapshot so every nearby client sees the same position.
local fields={'x','y','z','rx','ry','rz'}
local function cloneTransform(t,location)
    local base=Config.Attachment[location]
    local copy={bone=base.bone}
    for _,f in ipairs(fields) do
        copy[f]=(type(t)=='table' and tonumber(t[f])) or base[f]
    end
    return copy
end
local function clothesKey(ped)
    if not validPed(ped) then return nil end
    local sex=GetEntityModel(ped)==joaat('mp_m_freemode_01') and 'm' or 'f'
    local data={sex}
    -- Only clothing relevant to sling fit: torso, chains, undershirt, vest, outerwear.
    for _,comp in ipairs({3,7,8,9,11}) do
        data[#data+1]=('%d:%d,%d'):format(comp,GetPedDrawableVariation(ped,comp),GetPedTextureVariation(ped,comp))
    end
    return table.concat(data,'|')
end
local function mySling(location)
    local sid=GetPlayerServerId(PlayerId())
    for _,r in ipairs(state) do
        if r.location==location and tonumber(r.serverId)==sid then
            local key=tostring(r.id)
            local v=visible[key]
            if v and v.obj and DoesEntityExist(v.obj) and v.ped==PlayerPedId() and IsEntityAttachedToEntity(v.obj,v.ped) then
                return key,r,v
            end
        end
    end
    return nil
end
local function editorAttach()
    if not editor then return false end
    local v=visible[editor.recordId]
    if not v or not DoesEntityExist(v.obj) or v.ped~=PlayerPedId() then return false end
    return attachToSpine(v.obj,v.ped,editor.location,editor.values)
end
local function cancelEditor(silent)
    if not editor then return end
    local previous=editor
    editor=nil
    pendingEditorSave=nil
    local v=visible[previous.recordId]
    if v and DoesEntityExist(v.obj) then
        attachToSpine(v.obj,v.ped,previous.location,previous.original)
        v.applied=cloneTransform(previous.original,previous.location)
    end
    if not silent then message('Sling editor cancelled; nothing saved.') end
end
local function saveEditor()
    if not editor then return end
    if pendingEditorSave then return message('Position save in progress; wait for database confirmation.') end
    if clothesKey(PlayerPedId())~=editor.key then
        return cancelEditor(false)
    end
    if not editorAttach() then return message('Rifle attachment failed; position NOT saved.') end
    -- Keep preview/editor open until the server verifies the SQL write.
    -- This avoids claiming a position was saved while an event was rejected/busy.
    pendingEditorSave={location=editor.location,key=editor.key,
        recordId=editor.recordId,started=GetGameTimer()}
    TriggerServerEvent('dan6cd_sling:profile:save',editor.location,editor.key,editor.values)
    message('Saving outfit position to database...')
end
local function startEditor(location)
    if editor then return message('An editor is already open. Enter saves; Backspace cancels.') end
    if location~='front' and location~='back' then
        if mySling('front') then location='front'
        elseif mySling('back') then location='back'
        else return message('Use /sling or /backsling first, then /slingedit front or back.') end
    end
    local key=clothesKey(PlayerPedId())
    if not key then return message('Stock freemode character required.') end
    if outfitKey~=key then return message('Your outfit profile is still loading; retry editor in a moment.') end
    local recordId,r=mySling(location)
    if not recordId then return message('Sling a rifle on your '..location..' first, then open the editor.') end
    local original=cloneTransform(r.transform,location)
    pendingEditorSave=nil
    editor={recordId=recordId,location=location,key=key,original=original,
        values=cloneTransform(original,location),axis='rz',lastAdjust=0,shiftDownAt=nil}
    message(('Editor open (%s). Arrows move sideways/up; Page Up/Down depth; tap Shift to change rotation axis.'):format(location))
end
RegisterCommand('slingedit',function(_,args) startEditor(args[1] and args[1]:lower()) end,false)
RegisterCommand('slingeditcancel',function() cancelEditor(false) end,false)
local function drawEditorText(x,y,text,scale,color)
    SetTextFont(4)
    SetTextScale(0.0,scale or 0.30)
    SetTextColour(color and color[1] or 255,color and color[2] or 255,color and color[3] or 255,255)
    SetTextOutline()
    SetTextDropShadow()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x,y)
end
local function drawEditorHUD()
    local d=editor
    if not d then return end
    DrawRect(0.835,0.49,0.305,0.450,9,12,15,215)
    drawEditorText(0.695,0.287,'DAN6CD  |  SLING EDITOR',0.40,{255,255,255})
    drawEditorText(0.695,0.324,('SLOT: %s   |  OUTFIT PRESET'):format(d.location:upper()),0.28,{150,217,178})
    drawEditorText(0.695,0.363,('X  %+.3f     RX %+.1f'):format(d.values.x,d.values.rx),0.31)
    drawEditorText(0.695,0.394,('Y  %+.3f     RY %+.1f'):format(d.values.y,d.values.ry),0.31)
    drawEditorText(0.695,0.425,('Z  %+.3f     RZ %+.1f'):format(d.values.z,d.values.rz),0.31)
    drawEditorText(0.695,0.457,'ARROWS: LEFT/RIGHT / UP/DOWN',0.27)
    drawEditorText(0.695,0.486,'PAGE UP / DOWN: FORWARD / BACK',0.27)
    drawEditorText(0.695,0.515,('TAP L SHIFT: ROTATE AXIS [%s]'):format(d.axis:upper()),0.27,{150,217,178})
    drawEditorText(0.695,0.544,'Q / E: ROTATE - / +',0.27)
    drawEditorText(0.695,0.574,'HOLD L SHIFT: FASTER',0.27)
    drawEditorText(0.695,0.604,pendingEditorSave and 'SAVING... PLEASE WAIT' or 'ENTER SAVE   BACKSPACE CANCEL',0.27,{150,217,178})
    drawEditorText(0.695,0.633,'DELETE PREVIEW DEFAULT',0.27)
end
-- Native keyboard controls: arrow directions, PAGEUP/PAGEDOWN, left SHIFT,
-- Q/E and ENTER/BACKSPACE. Disable them while editing to avoid gameplay actions.
local editorControls={10,11,21,24,25,37,38,44,172,173,174,175,176,177,187,188,189,190,191,194,201,202,205,206,207,208,209,214}
local function pressedControl(id,alternative)
    return IsDisabledControlPressed(0,id) or (alternative and IsDisabledControlPressed(0,alternative)) or false
end
local function justPressedControl(id,alternative)
    return IsDisabledControlJustPressed(0,id) or (alternative and IsDisabledControlJustPressed(0,alternative)) or false
end
local function justReleasedControl(id,alternative)
    return IsDisabledControlJustReleased(0,id) or (alternative and IsDisabledControlJustReleased(0,alternative)) or false
end
-- Stock freemode upper-spine (24818) axes are not the same as generic world axes.
-- On the tested ped: bone X controls body height, bone Z controls left/right,
-- and bone Y controls forward/backward. Keep these configurable for ped builds.
local function applyMotion(d,action,step)
    local mapping=Config.EditorMotion or {
        left={'z',-1},right={'z',1},up={'x',1},down={'x',-1},
        forward={'y',1},backward={'y',-1}
    }
    local mappingRow=mapping[action]
    if not mappingRow then return false end
    local field,sign=mappingRow[1],tonumber(mappingRow[2])
    if (field~='x' and field~='y' and field~='z') or not sign then return false end
    local limit=tonumber(Config.EditorPositionLimit) or 0.5
    local before=d.values[field]
    d.values[field]=math.max(-limit,math.min(limit,before+sign*step))
    return d.values[field]~=before
end
CreateThread(function()
    while true do
        -- Capture the active editor session BEFORE yielding. A save reply,
        -- command or sling update can close/replace it while Wait() runs.
        local session=editor
        if not session then Wait(300)
        else
            Wait(0)
            -- v2.1.2: never dereference editor after Wait without checking that
            -- the exact same session is still active. This fixes nil editor at
            -- client.lua:427 when /slingedit back is opened/closed mid-frame.
            if editor==session then
            if not validPed(PlayerPedId()) or clothesKey(PlayerPedId())~=session.key or not mySling(session.location) then
                cancelEditor(true)
                message('Editor closed: player, clothing or rifle changed.')
            else
                for _,id in ipairs(editorControls) do DisableControlAction(0,id,true) end
                drawEditorHUD()
                local now=GetGameTimer()
                if pendingEditorSave and now-pendingEditorSave.started>8000 then
                    pendingEditorSave=nil
                    message('No save confirmation from server. Editor is open; check F8, then retry Enter.')
                end
                if pendingEditorSave then
                    -- Do not change values or cancel while an SQL write is in flight.
                elseif justPressedControl(201,191) then
                    saveEditor()
                elseif justPressedControl(202,194) then
                    cancelEditor(false)
                elseif justPressedControl(214,178) then
                    editor.values=cloneTransform(nil,editor.location)
                    editorAttach()
                else
                    local shift=pressedControl(21,209)
                    if justPressedControl(21,209) and not editor.shiftDownAt then
                        editor.shiftDownAt=now
                    end
                    if justReleasedControl(21,209) and editor.shiftDownAt then
                        -- Tapping SHIFT (<220ms) cycles Z -> Y -> X -> Z.
                        -- Holding it while adjusting instead accelerates movement.
                        if now-editor.shiftDownAt<220 then
                            editor.axis=editor.axis=='rz' and 'ry' or editor.axis=='ry' and 'rx' or 'rz'
                        end
                        editor.shiftDownAt=nil
                    end
                    if now-editor.lastAdjust>=65 then
                        local fast=shift and editor.shiftDownAt and (now-editor.shiftDownAt)>=220
                        local step=fast and 0.015 or 0.004
                        local turn=fast and 3.0 or 0.75
                        local action=nil
                        if pressedControl(174,189) then action='left'
                        elseif pressedControl(175,190) then action='right'
                        elseif pressedControl(172,188) then action='up'
                        elseif pressedControl(173,187) then action='down'
                        elseif pressedControl(10,208) then action='forward'
                        elseif pressedControl(11,207) then action='backward' end
                        local changed=action and applyMotion(editor,action,step) or false
                        local rotation=0
                        if pressedControl(44,205) then rotation=-1
                        elseif pressedControl(38,206) then rotation=1 end
                        if not action and rotation~=0 then
                            local axis=editor.axis
                            editor.values[axis]=math.max(-360,math.min(360,editor.values[axis]+rotation*turn))
                            changed=true
                        end
                        if changed then
                            editor.lastAdjust=now
                            editorAttach()
                        end
                    end
                end
            end
            end -- v2.1.2 editor session guard
        end
    end
end)
-- Outfit presets load from the server after spawn and when clothing changes.
-- Reloading a new outfit cannot mutate weapon inventory or sling ownership.
RegisterNetEvent('dan6cd_sling:profile:loaded',function(key)
    if type(key)=='string' and key==clothesKey(PlayerPedId()) then
        outfitKey=key -- database load has completed, safe to edit/save
        requestedOutfitKey=nil
    end
end)
-- Retry if the request arrived while a sling transfer held the player's lock.
-- Previously outfitKey was marked 'loaded' before the server replied, so one
-- missed event left the editor unable to save until reconnect.
CreateThread(function()
    while true do
        Wait(600)
        if not editor then
            local key=clothesKey(PlayerPedId())
            if not key then
                outfitKey=nil; requestedOutfitKey=nil
            elseif outfitKey~=key then
                local now=GetGameTimer()
                if requestedOutfitKey~=key or now-lastOutfitRequest>2500 then
                    requestedOutfitKey=key
                    lastOutfitRequest=now
                    TriggerServerEvent('dan6cd_sling:profile:select',key)
                end
            end
        end
    end
end)
RegisterNetEvent('dan6cd_sling:profile:saved',function(ok,reason,location,key)
    local waiting=pendingEditorSave
    if not waiting then return end
    if location and location~=waiting.location or key and key~=waiting.key then return end
    pendingEditorSave=nil
    if ok then
        -- Server confirmed that the SQL row is present and matches our values.
        -- The next snapshot contains the persisted transform for all clients.
        editor=nil
        message('Saved to MySQL: '..waiting.location..' position for this outfit. Re-sling to verify.')
    else
        message('NOT saved: '..tostring(reason or 'check server console')..'. Editor remains open.')
        TriggerServerEvent('dan6cd_sling:request')
    end
end)

-- One-shot diagnostic to distinguish bad offsets from a detached object.
RegisterCommand('slingattach',function()
    local count=0
    for key,e in pairs(visible) do
        if not e.ground then
            count=count+1
            local attached=e.obj and DoesEntityExist(e.obj) and e.ped
                and DoesEntityExist(e.ped) and IsEntityAttachedToEntity(e.obj,e.ped)
            local c=e.obj and DoesEntityExist(e.obj) and GetEntityCoords(e.obj)
            local p=e.ped and DoesEntityExist(e.ped) and GetEntityCoords(e.ped)
            local dist=(c and p) and #(c-p) or -1
            local info=('record=%s slot=%s attached=%s dist=%.2fm')
                :format(key,tostring(e.location),tostring(attached),dist)
            print('[dan6cd_weapon_sling] '..info)
            message(info)
        end
    end
    if count==0 then message('No slung rifle visible on this client. Check /slingstatus.') end
end,false)
CreateThread(function()
    while true do
        local nearest=scan()
        if nearest and not editor then
            -- Preserve a simple native GTA help prompt, no UI framework required.
            drawHelp('~INPUT_CONTEXT~  PICK UP ASSAULT RIFLE')
            if IsControlJustReleased(0,38) then TriggerServerEvent('dan6cd_sling:pickup',nearest.id);Wait(650) end
            Wait(0)
        else
            Wait(600)
        end
    end
end)
local function request()
    TriggerServerEvent('dan6cd_sling:request')
end
CreateThread(function() Wait(2500); request() end)
AddEventHandler('playerSpawned',function() outfitKey=nil;requestedOutfitKey=nil; Wait(1500);request() end)
RegisterNetEvent('QBCore:Client:OnPlayerLoaded',function() outfitKey=nil;requestedOutfitKey=nil;Wait(1200);request() end)
RegisterNetEvent('esx:playerLoaded',function() outfitKey=nil;requestedOutfitKey=nil;Wait(1200);request() end)
RegisterNetEvent('qbx_core:client:playerLoaded',function() outfitKey=nil;requestedOutfitKey=nil;Wait(1200);request() end)
AddEventHandler('onResourceStop',function(name)
    if name==GetCurrentResourceName() then editor=nil;for key in pairs(visible) do clear(key) end end
end)
