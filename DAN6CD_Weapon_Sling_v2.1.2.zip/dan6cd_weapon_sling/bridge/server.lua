-- Stock inventory adapters. Keep transfer functions here; never trust client metadata.
Bridge = {}
local started = function(name) return GetResourceState(name) == 'started' end
local framework = Config.Framework
if framework == 'auto' then
    framework = started('qbx_core') and 'qbox' or started('qb-core') and 'qbcore' or started('es_extended') and 'esx' or nil
end
local inventory = Config.Inventory
if inventory == 'auto' then
    inventory = started('ox_inventory') and 'ox' or (framework == 'qbcore' and started('qb-inventory')) and 'qb'
        or (framework == 'esx' and 'esx_native') or nil
end
local allowed = (framework == 'qbox' and inventory == 'ox')
    or (framework == 'qbcore' and (inventory == 'qb' or inventory == 'ox'))
    or (framework == 'esx' and (inventory == 'ox' or inventory == 'esx_native'))
if not allowed then
    error(('[dan6cd_weapon_sling] Unsupported framework / inventory: %s / %s'):format(tostring(framework), tostring(inventory)))
end
Bridge.framework, Bridge.inventory = framework, inventory
print(('[dan6cd_weapon_sling] %s + %s (stock clothing, no asset packs)'):format(framework, inventory))

local function player(src)
    if framework == 'qbox' then return exports.qbx_core:GetPlayer(src) end
    if framework == 'qbcore' then return exports['qb-core']:GetPlayer(src) end
    return exports['es_extended']:getSharedObject().GetPlayerFromId(src)
end
function Bridge.identifier(src)
    local p = player(src)
    if not p then return nil end
    if framework == 'esx' then return p.identifier end
    return p.PlayerData and p.PlayerData.citizenid or nil
end
local function serial(md)
    return type(md) == 'table' and (md.serial or md.serie) or nil
end
local function copy(md)
    local x = {}
    for k,v in pairs(type(md) == 'table' and md or {}) do x[k] = v end
    return x
end
local function saveNative(id, md)
    return MySQL.update.await('INSERT INTO dan6cd_sling_native (identifier,weapon,metadata) VALUES (?,?,?) ON DUPLICATE KEY UPDATE metadata=VALUES(metadata)',
        {id, Config.WeaponName, json.encode(md)}) ~= nil
end
local function loadNative(src)
    local p, id = player(src), Bridge.identifier(src)
    if not p or not id then return nil end
    local _, w = p.getWeapon(Config.WeaponName)
    if not w then return nil end
    local row = MySQL.single.await('SELECT metadata FROM dan6cd_sling_native WHERE identifier=? AND weapon=?', {id,Config.WeaponName})
    local md = row and json.decode(row.metadata) or {}
    if type(md) ~= 'table' then md = {} end
    if not md.serial then md.serial = ('ESX-%s-%d-%d'):format(id:gsub('[^%w]',''),os.time(),math.random(100000,999999)) end
    md.ammo = tonumber(w.ammo) or 0
    md.tint = tonumber(w.tintIndex) or 0
    md.components = w.components or {}
    if not saveNative(id,md) then return nil end
    return {name=Config.WeaponName, slot=1, metadata=md}
end
function Bridge.getSlot(src, slot)
    if inventory == 'esx_native' then return slot == 1 and loadNative(src) or nil end
    if type(slot) ~= 'number' or slot < 1 or slot % 1 ~= 0 then return nil end
    local item
    if inventory == 'ox' then item = exports.ox_inventory:GetSlot(src,slot)
    else item = exports['qb-inventory']:GetItemBySlot(src,slot) end
    if not item or tostring(item.name):upper() ~= Config.WeaponName then return nil end
    return {name=Config.WeaponName, slot=tonumber(item.slot), metadata=copy(inventory == 'ox' and item.metadata or item.info), amount = item.count or item.amount or 1}
end
function Bridge.getSelected(src, proposedSlot)
    -- ESX native has one loadout instance of a weapon type.
    if inventory == 'esx_native' then return loadNative(src) end
    local item = Bridge.getSlot(src,tonumber(proposedSlot))
    if not item or item.amount ~= 1 then return nil end
    if inventory == 'qb' then
        -- Native QB selected ped weapon alone cannot differentiate duplicate slots.
        local p = player(src)
        local matches = 0
        for _, it in pairs(p and p.PlayerData and p.PlayerData.items or {}) do
            if tostring(it.name):upper() == Config.WeaponName then matches = matches + 1 end
        end
        if matches ~= 1 then return nil end
    end
    return item
end
function Bridge.remove(src, item)
    local actual = Bridge.getSlot(src,item.slot)
    if not actual or tostring(serial(actual.metadata)) ~= tostring(serial(item.metadata)) then return false end
    if inventory == 'ox' then
        return exports.ox_inventory:RemoveItem(src,Config.WeaponName,1,actual.metadata,item.slot) == true
    elseif inventory == 'qb' then
        return exports['qb-inventory']:RemoveItem(src,Config.WeaponName:lower(),1,item.slot,'dan6cd_sling:remove') == true
    end
    local p, id = player(src), Bridge.identifier(src)
    if not p or not id then return false end
    if p.removeWeapon(Config.WeaponName) ~= true then return false end
    -- If this write fails the pending DB row still blocks automatic restoration.
    local written = MySQL.update.await('DELETE FROM dan6cd_sling_native WHERE identifier=? AND weapon=?',{id,Config.WeaponName})
    return written ~= nil
end
function Bridge.hasSerial(src, sn)
    if inventory == 'esx_native' then
        local item=loadNative(src)
        return item and tostring(serial(item.metadata)) == tostring(sn) or false
    end
    if inventory == 'ox' then
        for _, item in pairs(exports.ox_inventory:Search(src,'slots',Config.WeaponName) or {}) do
            if tostring(serial(item.metadata)) == tostring(sn) then return true end
        end
    else
        local p = player(src)
        for _, item in pairs(p and p.PlayerData and p.PlayerData.items or {}) do
            if tostring(item.name):upper() == Config.WeaponName and tostring(serial(item.info)) == tostring(sn) then return true end
        end
    end
    return false
end
function Bridge.give(src, md, preferredSlot)
    if type(md) ~= 'table' or not serial(md) then return false end
    if Bridge.hasSerial(src,serial(md)) then return false end
    if inventory == 'ox' then
        local ok = exports.ox_inventory:AddItem(src,Config.WeaponName,1,md,preferredSlot)
        if not ok and preferredSlot then ok = exports.ox_inventory:AddItem(src,Config.WeaponName,1,md) end
        return ok == true
    elseif inventory == 'qb' then
        local ok = exports['qb-inventory']:AddItem(src,Config.WeaponName:lower(),1,preferredSlot or false,md,'dan6cd_sling:return')
        if not ok and preferredSlot then ok = exports['qb-inventory']:AddItem(src,Config.WeaponName:lower(),1,false,md,'dan6cd_sling:return') end
        return ok == true
    end
    local p, id=player(src),Bridge.identifier(src)
    if not p or not id or p.hasWeapon(Config.WeaponName) then return false end
    if not saveNative(id,md) then return false end
    if p.addWeapon(Config.WeaponName,tonumber(md.ammo) or 0) == false then return false end
    for _,comp in pairs(type(md.components) == 'table' and md.components or {}) do
        if type(comp)=='string' then p.addWeaponComponent(Config.WeaponName,comp) end
    end
    if tonumber(md.tint) and tonumber(md.tint) > 0 then p.setWeaponTint(Config.WeaponName,tonumber(md.tint)) end
    return true
end
