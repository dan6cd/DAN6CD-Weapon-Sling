# DAN6CD Weapon Sling v2.1.2 — Back sling editor crash fix (TEST)

## Fixed
- `client.lua:427: attempt to index a nil value (upvalue editor)`.
- The editor coroutine used `Wait(0)` then read `editor.key` and `editor.location`; save acknowledgement / another event could set `editor=nil` while the coroutine was suspended.
- The editor now captures its session before yielding and resumes work only if the same session still exists. A closed/replaced session skips that frame.

## Not changed
- `/slingedit front` and `/slingedit back`, J and K, item records, database tables, saved profile values, stock clothing, and server inventory adapters.
- `ox_inventory` reported a separate native error in the supplied screenshot. This hotfix does not modify ox_inventory.

## Install
1. Stop `dan6cd_weapon_sling` and back up its folder.
2. Replace resource files using the included `dan6cd_weapon_sling` folder, or replace ONLY `client.lua` if you are running the unmodified v2.1.1 edition.
3. In the txAdmin/server console: `restart dan6cd_weapon_sling`.
4. Press K to place the Assault Rifle on your back, then `/slingedit back`.
5. Adjust arrows (body left/right/up/down), Page Up/Down (forward/back), tap Shift for rotation axis, Q/E rotate; Enter saves; Backspace cancels.
6. Wait for `Saved to MySQL`. Return rifle to inventory and re-sling to verify persistence.

This is a narrowly scoped source fix with Lua syntax and deterministic coroutine-race tests; live FiveM verification is still needed.
