# Troubleshooting and reconciliation — DAN6CD Weapon Sling

## Before testing

- Confirm no duplicate original sling script is running; no second system owns the same weapon.
- Check `oxmysql`, framework, and inventory are started correctly before `dan6cd_weapon_sling`.
- Test with stock male / female freemode character.
- Verify the Assault Rifle item has a unique serial (ox: `metadata.serial`; qb: `info.serie` / `info.serial`).
- To inspect stock drawable indices, run `/slingclothes`.

## Pending/returning rows

`dan6cd_sling_items.status='pending'`: the DB reservation was created but the inventory removal and DB activation did not both complete.

`status='returning'`: an inventory grant was attempted; the DB row was deliberately made nonrendering to prevent a duplicate.

**NEVER run blind SQL to mark these rows `active` or duplicate weapons.** Check the exact serial in the player's inventory/ESX loadout first, check if a row exists with that serial, and decide which side is the authoritative owner. If inventory already holds the weapon, delete the stranded row only after verifying there is no competing row or physical item. If the item is missing from inventory, reconcile the pending/returning record only after audit.

```sql
SELECT id, identifier, weapon, serial, location, status, original_slot, updated_at
FROM dan6cd_sling_items ORDER BY updated_at DESC;
```

For ESX native, the sidecar `dan6cd_sling_native` stores serial, ammo, tint and component information. Native ESX does not provide multiple unique items of the same type; do not treat it like ox_inventory.

## Compatibility limitations

- QB multiple copies of the same rifle are intentionally refused when taking from inventory.
- One stock weapon supported and one rifle per front/back slot. No swap when occupied.
- Returning a rifle places it in inventory; re-equip through the normal inventory before aiming.
- The weapon prop itself is a game-native prop (no visual clothing strap is supplied).
