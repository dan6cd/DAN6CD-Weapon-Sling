local locked = {}
local function notify(src,msg) TriggerClientEvent('dan6cd_sling:message',src,msg) end
local function logDebug(msg) if Config.Debug then print('[dan6cd_weapon_sling] '..tostring(msg)) end end
local function safeAction(src,callback)
    if locked[src] then return notify(src,'Weapon transfer already in progress.') end
    locked[src]=true
    local ok,err=xpcall(callback,debug.traceback)
    locked[src]=nil
    if not ok then
        print(('[dan6cd_weapon_sling] Transaction error for %s: %s'):format(src,err))
        notify(src,'Weapon action failed; contact staff before trying again.')
    end
end
local function ident(src) return Bridge.identifier(src) end
local function getSlot(id,slot)
    return MySQL.single.await("SELECT * FROM dan6cd_sling_items WHERE identifier=? AND location=? AND status='active' LIMIT 1",{id,slot})
end
local function validSource(src)
    local id=ident(src)
    if not id then notify(src,'Wait until your character has loaded.');return nil end
    local ped=GetPlayerPed(src)
    if not ped or ped==0 then return nil end
    local model=GetEntityModel(ped)
    if model ~= joaat('mp_m_freemode_01') and model ~= joaat('mp_f_freemode_01') then
        notify(src,'Use a stock male or female freemode ped.')
        return nil
    end
    return id,ped
end
local function disarm(src)
    TriggerClientEvent('dan6cd_sling:disarm',src)
end
local function metadata(row)
    local ok,decoded=pcall(json.decode,row.metadata or '{}')
    return ok and type(decoded)=='table' and decoded or {}
end
local function vectorPlacement(src,ped)
    local pos, h = GetEntityCoords(ped),GetEntityHeading(ped)
    -- GTA heading: 0 = north (positive Y).
    local rad=math.rad(h)
    return pos.x-math.sin(rad)*Config.DropDistance, pos.y+math.cos(rad)*Config.DropDistance, pos.z-0.75, h
end
local function sendSnapshot(target)
    local rows=MySQL.query.await("SELECT id,identifier,location,status,world_x,world_y,world_z,heading FROM dan6cd_sling_items WHERE status='active'") or {}
    local online={}
    for _,id in ipairs(GetPlayers()) do
        local sid=tonumber(id)
        local playerIdent=ident(sid)
        if playerIdent then online[playerIdent]=sid end
    end
    local entries={}
    for _,r in ipairs(rows) do
        if r.location=='ground' or online[r.identifier] then
            entries[#entries+1]={id=r.id,location=r.location,serverId=online[r.identifier],x=r.world_x,y=r.world_y,z=r.world_z,h=r.heading}
        end
    end
    TriggerClientEvent('dan6cd_sling:snapshot',target or -1,entries)
end
local function storeFromInventory(src,id,location,slot,ped)
    local item=Bridge.getSelected(src,tonumber(slot))
    if not item then return notify(src,'Equip one Assault Rifle. For QB, only one copy can be carried at a time.') end
    local sn=item.metadata and (item.metadata.serial or item.metadata.serie)
    if not sn or tostring(sn)=='' then
        return notify(src,'Weapon has no serial. This script refuses unsafe transfers.')
    end
    if getSlot(id,'front') and location=='front' or getSlot(id,'back') and location=='back' then
        return notify(src,'Sling position is already occupied.')
    end
    -- Persistent pending record BEFORE inventory removal. Pending rows NEVER render or auto-return.
    -- This intentionally prioritizes preventing duplicates over unsafe automatic recovery.
    local x,y,z,h=0,0,0,0
    if location=='ground' then x,y,z,h=vectorPlacement(src,ped) end
    local ok,recordId=pcall(function()
        return MySQL.insert.await([[INSERT INTO dan6cd_sling_items
            (identifier,weapon,serial,metadata,location,status,original_slot,world_x,world_y,world_z,heading)
            VALUES (?,?,?,?,?,'pending',?,?,?,?,?)]],
            {id,Config.WeaponName,tostring(sn),json.encode(item.metadata),location,tonumber(item.slot),x,y,z,h})
    end)
    if not ok or not recordId then
        return notify(src,'Could not reserve weapon; check duplicate serial or SQL errors.')
    end
    local removed=Bridge.remove(src,item)
    if not removed then
        -- A removal error can be ambiguous (especially with external inventories).
        -- Leave pending if it may have been removed; admin can resolve with SQL.
        local stillHere=Bridge.hasSerial(src,sn)
        if stillHere then
            MySQL.update.await("DELETE FROM dan6cd_sling_items WHERE id=? AND status='pending'",{recordId})
            return notify(src,'Inventory rejected transfer; rifle was not moved.')
        end
        print(('[dan6cd_weapon_sling] WARNING: pending transfer id=%s serial=%s. Manual reconciliation required.'):format(recordId,sn))
        return notify(src,'Transfer uncertain. Contact staff; DO NOT spawn another rifle.')
    end
    local updated=MySQL.update.await("UPDATE dan6cd_sling_items SET status='active' WHERE id=? AND status='pending'",{recordId})
    if updated~=1 then
        print(('[dan6cd_weapon_sling] WARNING: inventory removed but pending id %s not activated. Manual recovery needed.'):format(recordId))
        return notify(src,'Database update failed. Contact staff for recovery.')
    end
    disarm(src)
    notify(src,location=='ground' and 'Assault Rifle dropped.' or ('Assault Rifle placed on '..location..' sling.'))
    sendSnapshot()
end
local function returnRow(src,row)
    local md=metadata(row)
    if not md.serial and row.serial then md.serial=row.serial end
    if Bridge.hasSerial(src,row.serial) then
        return notify(src,'Same serial already in inventory. Staff must reconcile this record.')
    end
    local claimed=MySQL.update.await("UPDATE dan6cd_sling_items SET status='returning' WHERE id=? AND status='active'",{row.id})
    if claimed~=1 then return notify(src,'Weapon was already claimed.') end
    -- Once an item was added, NEVER blindly re-enable its physical row on SQL errors.
    local ok,added=pcall(Bridge.give,src,md,tonumber(row.original_slot))
    if not ok or not added then
        if Bridge.hasSerial(src,row.serial) then
            print(('[dan6cd_weapon_sling] CRITICAL: item added but adapter reported failure, row %d left returning.'):format(row.id))
            return notify(src,'Transfer status uncertain; staff must reconcile.')
        end
        MySQL.update.await("UPDATE dan6cd_sling_items SET status='active' WHERE id=? AND status='returning'",{row.id})
        return notify(src,'No inventory space, or framework could not return rifle.')
    end
    local deleted=MySQL.update.await("DELETE FROM dan6cd_sling_items WHERE id=? AND status='returning'",{row.id})
    if deleted~=1 then
        print(('[dan6cd_weapon_sling] CRITICAL: row %s remains returning; do not force recovery without checking inventory.'):format(row.id))
    end
    notify(src,'Assault Rifle returned to your inventory.')
    sendSnapshot()
end
local function toggle(src,location,slot)
    safeAction(src,function()
        local id,ped=validSource(src)
        if not id then return end
        local row=getSlot(id,location)
        if row then return returnRow(src,row) end
        if type(slot)~='number' then return notify(src,'Equip an Assault Rifle first.') end
        storeFromInventory(src,id,location,slot,ped)
    end)
end
RegisterNetEvent('dan6cd_sling:toggle',function(location,slot)
    local src=source
    if location~='front' and location~='back' then return end
    toggle(src,location,slot)
end)
RegisterNetEvent('dan6cd_sling:drop',function(slot,from)
    local src=source
    safeAction(src,function()
        local id,ped=validSource(src)
        if not id then return end
        if from=='front' or from=='back' then
            local row=getSlot(id,from)
            if not row then return notify(src,'That sling is empty.') end
            local x,y,z,h=vectorPlacement(src,ped)
            local changed=MySQL.update.await([[UPDATE dan6cd_sling_items SET location='ground',
                world_x=?,world_y=?,world_z=?,heading=? WHERE id=? AND status='active']],{x,y,z,h,row.id})
            if changed~=1 then return notify(src,'Unable to drop sling rifle.') end
            notify(src,'Slung rifle placed on the ground.')
            sendSnapshot()
        elseif type(slot)=='number' then
            storeFromInventory(src,id,'ground',slot,ped)
        else
            notify(src,'Equip a rifle, or use /dropgun front or /dropgun back.')
        end
    end)
end)
RegisterNetEvent('dan6cd_sling:pickup',function(recordId)
    local src=source
    safeAction(src,function()
        local id,ped=validSource(src)
        if not id then return end
        recordId=tonumber(recordId)
        if not recordId or recordId<1 or recordId%1~=0 then return end
        local row=MySQL.single.await("SELECT * FROM dan6cd_sling_items WHERE id=? AND location='ground' AND status='active'",{recordId})
        if not row then return end
        local pos=GetEntityCoords(ped)
        local dx,dy,dz=pos.x-row.world_x,pos.y-row.world_y,pos.z-row.world_z
        if dx*dx+dy*dy+dz*dz>(Config.PickupDistance+0.75)^2 then return notify(src,'Move closer to the rifle.') end
        returnRow(src,row)
    end)
end)
RegisterNetEvent('dan6cd_sling:request',function()
    local src=source
    safeAction(src,function()
        local id=ident(src)
        if id then sendSnapshot(-1) end
    end)
end)
RegisterCommand('slingstatus',function(src)
    if src==0 then return end
    local id=ident(src)
    if not id then return end
    safeAction(src,function()
        for _,row in ipairs(MySQL.query.await('SELECT id,location,status,serial FROM dan6cd_sling_items WHERE identifier=?',{id}) or {}) do
            notify(src,('%s: %s / %s / %s'):format(row.id,row.location,row.status,row.serial))
        end
    end)
end)
AddEventHandler('playerDropped',function() locked[source]=nil; SetTimeout(1000,function() sendSnapshot() end) end)
AddEventHandler('onResourceStart',function(resource)
    if resource~=GetCurrentResourceName() then return end
    CreateThread(function() Wait(1500); sendSnapshot() end)
end)
