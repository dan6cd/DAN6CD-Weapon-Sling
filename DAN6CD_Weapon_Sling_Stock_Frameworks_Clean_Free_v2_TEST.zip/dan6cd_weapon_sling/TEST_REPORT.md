# Test report — v2.0.0-clean-test

- Manifest/config/client/server/bridge parsed successfully with Lua `loadfile` (texlua runtime).
- Server adapter round-trip smoke test passed for Qbox+ox_inventory, QBCore+qb-inventory, and ESX+native loadout, using fake player inventories, simulated serials and a mock SQL sidecar.
- Package audit: no custom YDD, YTD, assetpacks file, .fxap or escrowed Lua included. GTA V's built-in rifle prop is used.
- **Not yet verified**: true FiveM networking, ped bone offsets, animation and controls, MySQL transactions against a live server, concurrent players, restart recovery, actual stock clothing indices, ESX ammo sync, and inventory API behavior across all versions.
- State transitions intentionally leave ambiguous transfers in `pending` / `returning` for staff reconciliation rather than spawning duplicates.
- This rebuild does **not migrate** your prior protected or unprotected sling database records. Do not deploy against live character weapons without backups and a clean test server.
