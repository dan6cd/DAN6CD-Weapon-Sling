-- DAN6CD free edition: vanilla GTA V weapon prop + existing stock freemode clothing.
local visible={} -- per-client cosmetic props only; never inventory items.
local state={}
local hash=joaat(Config.WeaponName)
local model=joaat(Config.WeaponModel)
local function message(text)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('~b~DAN6CD Weapon Sling~s~: '..tostring(text))
    EndTextCommandThefeedPostTicker(false,false)
end
RegisterNetEvent('dan6cd_sling:message',message)
local function validPed(ped)
    if ped==0 or not DoesEntityExist(ped) then return false end
    local m=GetEntityModel(ped)
    return m==joaat('mp_m_freemode_01') or m==joaat('mp_f_freemode_01')
end
local function clothingOK(ped)
    if not validPed(ped) then return false end
    if not Config.RequireStockClothing then return true end
    local gender=GetEntityModel(ped)==joaat('mp_m_freemode_01') and 'male' or 'female'
    for _,rule in ipairs(Config.StockClothing[gender] or {}) do
        if GetPedDrawableVariation(ped,rule.component)==rule.drawable
            and GetPedTextureVariation(ped,rule.component)==rule.texture then return true end
    end
    return false
end
local function selectedSlot()
    local ped=PlayerPedId()
    if GetSelectedPedWeapon(ped)~=hash then return nil end
    if GetResourceState('ox_inventory')=='started' then
        local ok,w=pcall(function() return exports.ox_inventory:getCurrentWeapon() end)
        return ok and w and tostring(w.name):upper()==Config.WeaponName and tonumber(w.slot) or nil
    end
    if GetResourceState('qb-inventory')=='started' then
        local ok,playerData=pcall(function() return exports['qb-core']:GetCoreObject().Functions.GetPlayerData() end)
        if not ok or not playerData then return nil end
        local count,slot=0,nil
        for _,w in pairs(playerData.items or {}) do
            if tostring(w.name):upper()==Config.WeaponName then
                count=count+1;slot=tonumber(w.slot)
            end
        end
        return count==1 and slot or nil
    end
    if GetResourceState('es_extended')=='started' then return 1 end
    return nil
end
local function toggle(location)
    if not clothingOK(PlayerPedId()) then
        return message('Use a stock freemode ped and an allowed stock clothing preset.')
    end
    TriggerServerEvent('dan6cd_sling:toggle',location,selectedSlot())
end
RegisterCommand('sling',function() toggle('front') end,false)
RegisterKeyMapping('sling','DAN6CD: front weapon sling','keyboard','J')
RegisterCommand('backsling',function() toggle('back') end,false)
RegisterCommand('dropgun',function(_,args)
    local from=args[1] and args[1]:lower() or nil
    if from~='front' and from~='back' then from=nil end
    TriggerServerEvent('dan6cd_sling:drop',selectedSlot(),from)
end,false)
RegisterCommand('slingclothes',function()
    local ped=PlayerPedId()
    if not validPed(ped) then return message('Stock freemode character required.') end
    local s={}
    for _,component in ipairs({3,7,8,9,11}) do
        s[#s+1]=('%d:%d/%d'):format(component,GetPedDrawableVariation(ped,component),GetPedTextureVariation(ped,component))
    end
    message('Stock clothing component:drawable/texture = '..table.concat(s,'  '))
end,false)
RegisterNetEvent('dan6cd_sling:disarm',function()
    if GetResourceState('ox_inventory')=='started' then TriggerEvent('ox_inventory:disarm',true) end
    local ped=PlayerPedId()
    SetCurrentPedWeapon(ped,joaat('WEAPON_UNARMED'),true)
    RemoveWeaponFromPed(ped,hash)
end)
RegisterNetEvent('dan6cd_sling:snapshot',function(snapshot)
    if type(snapshot)~='table' then return end
    state=snapshot
end)
local function clear(key)
    local value=visible[key]
    if value and value.obj and DoesEntityExist(value.obj) then DeleteEntity(value.obj) end
    visible[key]=nil
end
local function loadModel()
    if HasModelLoaded(model) then return true end
    RequestModel(model)
    return false
end
local function createProp()
    if not HasModelLoaded(model) then return nil end
    local obj=CreateObjectNoOffset(model,0.0,0.0,0.0,false,false,false)
    if obj==0 then return nil end
    SetEntityAsMissionEntity(obj,true,true)
    return obj
end
local function worldPosition(r)
    return vector3(tonumber(r.x) or 0,tonumber(r.y) or 0,tonumber(r.z) or 0)
end
local function drawHelp(text)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0,false,false,-1)
end
local function scan()
    local pos=GetEntityCoords(PlayerPedId())
    local wanted={}
    local nearest=nil
    local nearestD=Config.PickupDistance
    for _,r in ipairs(state) do
        local key=tostring(r.id)
        if r.location=='ground' then
            local target=worldPosition(r)
            local d=#(pos-target)
            if d<=Config.StreamDistance then
                wanted[key]={row=r,ground=true}
                if d<nearestD then nearestD=d; nearest=r end
            end
        elseif (r.location=='front' or r.location=='back') and r.serverId then
            local player=GetPlayerFromServerId(tonumber(r.serverId))
            if player~=-1 then
                local ped=GetPlayerPed(player)
                if validPed(ped) and #(pos-GetEntityCoords(ped))<=Config.StreamDistance then
                    wanted[key]={row=r,ped=ped,ground=false}
                end
            end
        end
    end
    for key in pairs(visible) do if not wanted[key] then clear(key) end end
    for key,w in pairs(wanted) do
        local old=visible[key]
        if not old or not DoesEntityExist(old.obj) or old.ped~=w.ped or old.ground~=w.ground then
            clear(key)
            if loadModel() then
                local obj=createProp()
                if obj then
                    if w.ground then
                        local target=worldPosition(w.row)
                        SetEntityCoordsNoOffset(obj,target.x,target.y,target.z,false,false,false)
                        SetEntityHeading(obj,tonumber(w.row.h) or 0.0)
                        PlaceObjectOnGroundProperly(obj)
                        FreezeEntityPosition(obj,true)
                        SetEntityCollision(obj,false,false)
                    else
                        local offset=Config.Attachment[w.row.location]
                        AttachEntityToEntity(obj,w.ped,GetPedBoneIndex(w.ped,offset.bone),
                            offset.x,offset.y,offset.z,offset.rx,offset.ry,offset.rz,
                            false,false,false,false,2,true)
                        SetEntityCollision(obj,false,false)
                    end
                    visible[key]={obj=obj,ped=w.ped,ground=w.ground}
                end
            end
        end
    end
    return nearest
end
CreateThread(function()
    while true do
        local nearest=scan()
        if nearest then
            -- Preserve a simple native GTA help prompt, no UI framework required.
            drawHelp('~INPUT_CONTEXT~  PICK UP ASSAULT RIFLE')
            if IsControlJustReleased(0,38) then TriggerServerEvent('dan6cd_sling:pickup',nearest.id);Wait(650) end
            Wait(0)
        else
            Wait(600)
        end
    end
end)
local function request()
    TriggerServerEvent('dan6cd_sling:request')
end
CreateThread(function() Wait(2500); request() end)
AddEventHandler('playerSpawned',function() Wait(1500);request() end)
RegisterNetEvent('QBCore:Client:OnPlayerLoaded',function() Wait(1200);request() end)
RegisterNetEvent('esx:playerLoaded',function() Wait(1200);request() end)
RegisterNetEvent('qbx_core:client:playerLoaded',function() Wait(1200);request() end)
AddEventHandler('onResourceStop',function(name)
    if name==GetCurrentResourceName() then for key in pairs(visible) do clear(key) end end
end)
