fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'DAN6CD'
description 'Free, source-readable stock-clothing rifle sling for Qbox, QBCore and ESX Legacy'
version '2.0.0-clean-test'

shared_script 'config.lua'
client_scripts { 'client.lua' }
server_scripts { '@oxmysql/lib/MySQL.lua', 'bridge/server.lua', 'server.lua' }
dependency 'oxmysql'
