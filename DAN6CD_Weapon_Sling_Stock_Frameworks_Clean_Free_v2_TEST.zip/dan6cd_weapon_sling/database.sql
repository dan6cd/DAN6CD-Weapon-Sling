-- New independent storage. NEVER import old weapon_sling or physical_core tables automatically.
CREATE TABLE IF NOT EXISTS dan6cd_sling_items (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identifier VARCHAR(120) NOT NULL,
    weapon VARCHAR(80) NOT NULL,
    serial VARCHAR(120) NOT NULL,
    metadata LONGTEXT NOT NULL,
    location VARCHAR(10) NOT NULL,
    status VARCHAR(15) NOT NULL DEFAULT 'pending',
    original_slot INT DEFAULT NULL,
    world_x DOUBLE DEFAULT NULL,
    world_y DOUBLE DEFAULT NULL,
    world_z DOUBLE DEFAULT NULL,
    heading DOUBLE DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_dan6cd_serial (serial),
    INDEX idx_owner_location_status (identifier,location,status),
    INDEX idx_ground_status (location,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dan6cd_sling_native (
    identifier VARCHAR(120) NOT NULL,
    weapon VARCHAR(80) NOT NULL,
    metadata LONGTEXT NOT NULL,
    PRIMARY KEY(identifier,weapon)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
