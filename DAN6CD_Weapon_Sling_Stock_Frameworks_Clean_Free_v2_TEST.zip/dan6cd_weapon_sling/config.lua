Config = {}
-- Auto-detect the normal stock setup. Override only when using a nonstandard load order.
Config.Framework = 'auto' -- auto | qbox | qbcore | esx
Config.Inventory = 'auto' -- auto | ox | qb | esx_native

-- No extra clothing or assets are streamed. The rifle attaches to the freemode ped
-- in whatever *stock* clothing the player is already wearing.
Config.RequireStockClothing = false
-- Optional stock clothing whitelist. Set RequireStockClothing=true after checking
-- the actual drawable/texture on your stock GTA V build with /slingclothes.
-- These sample values are NOT required or automatically applied.
Config.StockClothing = {
    male = { { component = 8, drawable = 18, texture = 0 } },
    female = { { component = 8, drawable = 17, texture = 3 } }
}

Config.PickupDistance = 2.0
Config.DropDistance = 1.0
Config.StreamDistance = 80.0
Config.Debug = false

-- Only the verified Assault Rifle from the original free sling is enabled.
-- Further stock weapons must be calibrated and tested before adding them here.
Config.WeaponName = 'WEAPON_ASSAULTRIFLE'
Config.WeaponModel = 'w_ar_assaultrifle'
Config.Attachment = {
    front = { bone = 24818, x = -0.17, y = 0.265, z = -0.135, rx = 0.0, ry = 150.0, rz = 15.0 },
    back  = { bone = 24818, x = 0.12, y = -0.22, z = 0.04, rx = 0.0, ry = 145.0, rz = 0.0 }
}
