# Automated compatibility tests (mocked APIs only)

- Parsed all Lua files using the Lua interpreter after substituting FiveM hash backticks: **PASS**.
- QBCore + qb-inventory: normalize `info.serie`, remove from exact slot, restore same slot with serial, ammo, quality; reject duplicate serial: **PASS**.
- Qbox + ox_inventory: remove and restore same serialized weapon with exactly preserved original metadata (no QB fields added): **PASS**.
- ESX Legacy native loadout: generate/persist serial sidecar, remove weapon, restore ammo/components/tint, preserve serial, reject duplicate: **PASS**.

**Not tested:** a live FiveM client, live MySQL, on-server stream model rendering, live qb-inventory equip event, restart/reconnect, rapid transactions, ESX native component compatibility across every version. These tests must be performed on a disposable development server with database backups before public production release.
