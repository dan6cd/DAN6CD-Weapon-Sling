fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'DAN6CD | Weapon Sling original adapted for framework compatibility'
description 'FREE physical rifle sling for Qbox, QBCore, ESX Legacy (multi inventory)'
version '1.0.0-free'
shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}
client_scripts {
    'compat/client.lua',
    'client.lua'
}
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'compat/server.lua',
    'server.lua'
}
dependencies { 'ox_lib', 'oxmysql' }
files {
    'stream/male/*.ydd',
    'stream/male/*.ytd',
    'stream/female/*.ydd',
    'stream/female/*.ytd'
}

dependency '/assetpacks'