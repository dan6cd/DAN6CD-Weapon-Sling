-- Weapon Sling v0.3 migration for an EXISTING physical_items table.
-- BACK UP physical_items before running this migration.

ALTER TABLE `physical_items`
    ADD COLUMN `serial` VARCHAR(100) DEFAULT NULL AFTER `item_type`;

-- Backfill serials from the existing metadata JSON.
UPDATE `physical_items`
SET `serial` = JSON_UNQUOTE(JSON_EXTRACT(`metadata`, '$.serial'))
WHERE `metadata` IS NOT NULL
  AND `metadata` <> ''
  AND JSON_VALID(`metadata`)
  AND JSON_EXTRACT(`metadata`, '$.serial') IS NOT NULL;

-- Run these checks BEFORE adding the unique keys. Both queries should return 0 rows.
SELECT `serial`, COUNT(*) AS `copies`
FROM `physical_items`
WHERE `serial` IS NOT NULL AND `serial` <> ''
GROUP BY `serial`
HAVING COUNT(*) > 1;

SELECT `citizenid`, `location_type`, `location_slot`, COUNT(*) AS `copies`
FROM `physical_items`
WHERE `citizenid` IS NOT NULL
GROUP BY `citizenid`, `location_type`, `location_slot`
HAVING COUNT(*) > 1;

-- If both checks above return 0 rows, run the following ALTER.
-- If either check returns rows, reconcile those duplicates first.
ALTER TABLE `physical_items`
    ADD UNIQUE KEY `uq_physical_items_serial` (`serial`),
    ADD UNIQUE KEY `uq_player_equipment_slot` (`citizenid`, `location_type`, `location_slot`);
