CREATE TABLE IF NOT EXISTS `weapon_sling_items` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(100) DEFAULT NULL,
    `item_name` VARCHAR(100) NOT NULL,
    `item_type` VARCHAR(50) NOT NULL DEFAULT 'item',
    `serial` VARCHAR(100) DEFAULT NULL,
    `metadata` LONGTEXT DEFAULT NULL,
    `location_type` VARCHAR(50) NOT NULL,
    `location_slot` VARCHAR(100) DEFAULT NULL,
    `world_x` DOUBLE DEFAULT NULL,
    `world_y` DOUBLE DEFAULT NULL,
    `world_z` DOUBLE DEFAULT NULL,
    `world_heading` DOUBLE DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_weapon_sling_items_serial` (`serial`),
    UNIQUE KEY `uq_player_equipment_slot` (`citizenid`, `location_type`, `location_slot`),
    INDEX `idx_weapon_sling_items_citizenid` (`citizenid`),
    INDEX `idx_weapon_sling_items_location` (`location_type`, `location_slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `weapon_sling_transforms` (
 `citizenid` VARCHAR(100) NOT NULL,
 `equipment_slot` VARCHAR(64) NOT NULL,
 `bone` INT NOT NULL,
 `pos_x` DOUBLE NOT NULL, `pos_y` DOUBLE NOT NULL, `pos_z` DOUBLE NOT NULL,
 `rot_x` DOUBLE NOT NULL, `rot_y` DOUBLE NOT NULL, `rot_z` DOUBLE NOT NULL,
 `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`citizenid`,`equipment_slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `weapon_sling_native_metadata` (
 `citizenid` VARCHAR(100) NOT NULL,
 `weapon_name` VARCHAR(100) NOT NULL,
 `metadata` LONGTEXT NOT NULL,
 PRIMARY KEY (`citizenid`,`weapon_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
